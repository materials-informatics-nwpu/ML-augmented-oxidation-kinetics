
################################ --- FUNCTIONS --- ########################################
############ plot function ###########
fn.plot.model = function(mean, sd, measured){    ########## new function
  plot(mean ~ measured, xlab = "Measured Values", ylab = "Predicted Values",
       pch = 1, col = "darkblue", cex = 1.5, bg="darkblue", xlim = c(0, 300000), ylim = c(0, 300000))
  arrows(measured, mean - 0.5*sd, measured, mean + 0.5*sd, length = 0.08, angle = 90, code = 3, col = "darkblue")
  abline(0,1, col = "red", lwd = 2.0)
}

fn.plot.prevsmea = function(model, data){
  plot(predict(model,data) ~ data$es, 
       ylab = "Predicted values", xlab = "Measured values",
       pch = 21, col = "darkblue", cex = 1.5, bg="darkblue",xlim = c(0, 300000), ylim = c(0, 300000))
  abline(0, 1, lwd =2, col = "red")
}

############ predict data through regression ############
fn.model.lm.6f = function(data.training, data.virtual){ ####### new function
  lm.fit.6f = glm (es ~. , data = data.training) ###### linear regression
  return(predict(lm.fit.6f, data.virtual)) ######### return prediction
}

fn.model.poly.123121 = function(data.training, data.virtual){
  model = glm(es ~ poly(distance,2) + poly(size,2), data = data.train_1)
  return(predict(model, data.virtual))
}
####### cross validation (in SVR) #########
fn.cv.svr.rbf = function(data){   ######## function to cross validation in SVR.rbf
  tuneResult.svr.rbf = tune(svm, es ~ ., data = data, 
                            kernel = "radial",
                            ranges = list(gamma = seq(0.1,3,0.5), cost = seq(0.1, 40.1, 10))
                            #ranges = list(epsilon = seq(0.2,1,0.2), cost = seq( 0.1,60.1, 20))
  )
  print(tuneResult.svr.rbf)
  #  plot(tuneResult.svr.rbf)
  return(tuneResult.svr.rbf$best.parameters) #### return best cross-validation error
}

fn.cv.svr.lin = function(data){   ######## function to cross validation in SVR.lin
  tuneResult.svr.lin = tune(svm, es ~ ., data = data,
                            kernel = "linear",
                            ranges = list(gamma = seq(0,1,0.4), cost = seq( 0.1,20, 8))
  )
  print(tuneResult.svr.lin)
  #plot(tuneResult.svr.rbf)
  return(tuneResult.svr.lin$best.parameters)
}

fn.cv.svr.poly = function(data){    ######## function to cross validation in SVR.poly
  tuneResult.svr.poly = tune(svm, es ~ ., data = data,
                             kernel = "polynomial",
                             ranges = list(gamma = seq(0,1,0.4), cost = seq( 0.1,20, 8))
  )
  print(tuneResult.svr.poly)
  #  plot(tuneResult.svr.rbf)
  return(tuneResult.svr.poly$best.parameters)
}


############ prediction through SVR model ##########
fn.model.svr.rbf = function(data.training, data.virtual){   ######### new function
  
  parameter.svr.rbf = fn.cv.svr.rbf(data.training)     ###### call function, just used in SVR model, not in linear or poly ......
  gamma = parameter.svr.rbf[1]   ##### 
  cost = parameter.svr.rbf[2]    #####
  model = svm(es ~. , data = data.training, kernel = "radial",     ########## regression
              gamma = gamma, cost = cost)
  
  predictions = predict(model,data.virtual)
  return (predictions)   ########## return prediction
}

fn.model.svr.lin = function(data.training, data.virtual){
  
  parameter.svr.lin = fn.cv.svr.lin(data.training)
  gamma = parameter.svr.lin[1]
  cost = parameter.svr.lin[2]
  model = svm(es ~. , data = data.training, kernel = "linear", 
              gamma = gamma, cost = cost)
  
  predictions = predict(model,data.virtual)
  return (predictions)
}

fn.model.svr.poly = function(data.training, data.virtual){
  
  parameter.svr.poly = fn.cv.svr.poly(data.training)
  gamma = parameter.svr.poly[1]
  cost = parameter.svr.poly[2]
  model = svm(es ~. , data = data.training, kernel = "polynomial", 
              gamma = gamma, cost = cost)
  
  predictions = predict(model,data.virtual)
  return (predictions)
}
################# lasso regression (like linear and poly regression) #################
fn.model.lasso.6f = function(data.training, data.virtual){
  x = model.matrix(es ~., data.training)[, -1]
  y = data.training$es
  lasso.fit.6f = glmnet(x, y, alpha = 1)
  cv.out = cv.glmnet(x, y, alpha = 1)
  bestlam = cv.out$lambda.min
  z = model.matrix(es ~., data.virtual)[, -1]
  return(predict(lasso.fit.6f, s = bestlam, newx = z))
}

################# gradient boosting regression (like linear and poly regression) #################
fn.model.Gboosting.6f = function(data.training, data.virtual){
  Gboosting.fit.6f = gbm(es ~ ., 
                         data = data.training, distribution = "gaussian", n.trees = 5000, interaction.depth = 7)
  return(predict(Gboosting.fit.6f, data.virtual, n.trees = 5000))
}

################# Random Forest #################
fn.model.rf = function(data.training, data.virtual){
  model1 <- randomForest(es ~ ., data = data.training, ntree = 500, mtry = 6, importance = TRUE)
  prediction = predict(model1, data.virtual, predict.all = T)
  #predicted.value = data.frame(prediction[1])
  predict.matrix = data.frame(prediction[2])
  #predict.matrix[, "sd"] = apply(predict.matrix, 1, sd)
  predict.matrix[, "mean"] = apply(predict.matrix, 1, mean)
  return(predict.matrix$mean)
}

############# boostrap #############
fn.boot.prop.mean.error = function(data.training,data.virtual,regressor,seed,B, property) {   ####### new function
  set.seed(seed)
  
  n = dim(data.training)[1]
  R = B-1                               ######## boostrap times
  
  if (regressor == "lm.fit.6f") {     ####### used model 
    predict.data = fn.model.lm.6f(data.training,data.virtual)     ######## call function "fn.model.lm.6f", used all the observation
    i=1
    repeat{
      # boot.sample = c(sample(n, 5, replace = FALSE), sample(n, n-5, replace = TRUE)) ## select 5 obvervation from n, replace=FALSE mean can't repeat, replace=TRUE can repeat 
      boot.sample = sample(n, n, replace = TRUE)        ## select n integer from n, can repeat
      t.data.training = data.training[boot.sample,]     ## data.training's boot.sample row
      predict.data1 = fn.model.lm.6f(t.data.training, data.virtual)  ## do regression use function just using observation in boot.sample
      predict.data = cbind(predict.data, predict.data1)   ## add the predic.data1 to predict.data
      i=i+1                                               ## repeat
      if(i>R) break ()
    }
  }
  
  if (regressor == "poly.fit.123121") {
    predict.data = fn.model.poly.123121(data.training,data.virtual)
    i=1
    repeat{
      #    boot.sample = c(sample(n, 5, replace = FALSE), sample(n, n-5, replace = TRUE))
      boot.sample = sample(n, n, replace = TRUE)
      t.data.training = data.training[boot.sample,]
      predict.data1 = fn.model.poly.123121(t.data.training, data.virtual)
      predict.data = cbind(predict.data, predict.data1)
      i=i+1    
      if(i>R) break ()
    }
  }
  
  if (regressor == "SVR.rbf") {
    predict.data = fn.model.svr.rbf(data.training,data.virtual)
    i=1
    repeat{
      #    boot.sample = c(sample(n, 5, replace = FALSE), sample(n, n-5, replace = TRUE))
      boot.sample = sample(n, n, replace = TRUE)
      t.data.training = data.training[boot.sample,]
      predict.data1 = fn.model.svr.rbf(t.data.training, data.virtual)
      predict.data = cbind(predict.data, predict.data1)
      i=i+1    
      if(i>R) break ()
    }
  }
  
  if (regressor == "SVR.lin") {
    predict.data = fn.model.svr.lin(data.training,data.virtual)
    i=1
    repeat{
      #    boot.sample = c(sample(n, 5, replace = FALSE), sample(n, n-5, replace = TRUE))
      boot.sample = sample(n, n, replace = TRUE)
      t.data.training = data.training[boot.sample,]
      predict.data1 = fn.model.svr.lin(t.data.training, data.virtual)
      predict.data = cbind(predict.data, predict.data1)
      i=i+1    
      if(i>R) break ()
    }
  }
  
  if (regressor == "SVR.poly") {
    predict.data = fn.model.svr.poly(data.training,data.virtual)
    i=1
    repeat{
      #    boot.sample = c(sample(n, 5, replace = FALSE), sample(n, n-5, replace = TRUE))
      boot.sample = sample(n, n, replace = TRUE)
      t.data.training = data.training[boot.sample,]
      predict.data1 = fn.model.svr.poly(t.data.training, data.virtual)
      predict.data = cbind(predict.data, predict.data1)
      i=i+1    
      if(i>R) break ()
    }
  }
  
  
  if (regressor == "lasso.fit.6f") {
    predict.data = fn.model.lasso.6f(data.training,data.virtual)
    i=1
    repeat{
      #    boot.sample = c(sample(n, 5, replace = FALSE), sample(n, n-5, replace = TRUE))
      boot.sample = sample(n, n, replace = TRUE)
      t.data.training = data.training[boot.sample,]
      predict.data1 = fn.model.lasso.6f(t.data.training, data.virtual)
      predict.data = cbind(predict.data, predict.data1)
      i=i+1    
      if(i>R) break ()
    }
  }
  
  
  if (regressor == "GB") {
    predict.data = fn.model.Gboosting.6f(data.training,data.virtual)
    i=1
    repeat{
      #    boot.sample = c(sample(n, 5, replace = FALSE), sample(n, n-5, replace = TRUE))
      boot.sample = sample(n, n, replace = TRUE)
      t.data.training = data.training[boot.sample,]
      predict.data1 = fn.model.Gboosting.6f(t.data.training, data.virtual)
      predict.data = cbind(predict.data, predict.data1)
      i=i+1    
      if(i>R) break ()
    }
  }
  
  if (regressor == "KRR") {     ####### used model 
    predict.data = fn.krr(data.training,data.virtual)     ######## call function "fn.model.lm.6f", used all the observation
    i=1
    repeat{
      # boot.sample = c(sample(n, 5, replace = FALSE), sample(n, n-5, replace = TRUE)) ## select 5 obvervation from n, replace=FALSE mean can't repeat, replace=TRUE can repeat 
      boot.sample = sample(n, n, replace = TRUE)        ## select n integer from n, can repeat
      t.data.training = data.training[boot.sample,]     ## data.training's boot.sample row
      predict.data1 = fn.krr(t.data.training, data.virtual)  ## do regression use function just using observation in boot.sample
      predict.data = cbind(predict.data, predict.data1)   ## add the predic.data1 to predict.data
      i=i+1                                               ## repeat
      print(i)
      if(i>R) break ()
    }
  }
  
  if (regressor == "RF") {     ####### used model 
    predict.data = fn.model.rf(data.training,data.virtual)     ######## call function "fn.model.lm.6f", used all the observation
    i=1
    repeat{
      # boot.sample = c(sample(n, 5, replace = FALSE), sample(n, n-5, replace = TRUE)) ## select 5 obvervation from n, replace=FALSE mean can't repeat, replace=TRUE can repeat 
      boot.sample = sample(n, n, replace = TRUE)        ## select n integer from n, can repeat
      t.data.training = data.training[boot.sample,]     ## data.training's boot.sample row
      predict.data1 = fn.model.rf(t.data.training, data.virtual)  ## do regression use function just using observation in boot.sample
      predict.data = cbind(predict.data, predict.data1)   ## add the predic.data1 to predict.data
      i=i+1                                               ## repeat
      print(i)
      if(i>R) break ()
    }
  }
  
  data.pre = cbind(rowMeans(predict.data), apply(predict.data,1,sd))
  colnames(data.pre) = c("mean","sd")
  return(data.frame(data.pre))
}

# # # # # # # # # # # FUNCTIONS  For EXPECTED IMPROVEMENT # # # # # # # # # # # # # # # # # #  

fn.EI =  function(data.train, data.virtual){
  
  ego = (data.virtual[,"mean"] - max(data.train[,"es"]))/data.virtual[,"sd"]
  z = ego
  ei.ego = data.virtual[,"sd"]*z*pnorm(z) + data.virtual[,"sd"]*dnorm(z) 
  kg = -1*abs((data.virtual[,"mean"] - max(max(data.virtual[,"mean"]),max(data.train[,"es"])))/data.virtual[,"sd"])
  z = kg
  ei.kg = data.virtual[,"sd"]*z*pnorm(z) + data.virtual[,"sd"]*dnorm(z)  
  
  #max.P = pnorm(ego, mean = data.virtual[,"mean"], sd = data.virtual[,"sd"])
  
  ei = cbind(data.virtual, ei.ego, ei.kg)
  ei = data.frame(ei)
  return (ei)
}


# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #
# # # # # # # # # # # # # # # devided into batch # # # # # # # # # # # # # # # # # # # # # #

fn.boot.es.mean.error = function(data.training, data.virtual, regressor, seed, batch, bootsnum){  ## new function
  
  set.seed(seed)  
  n = dim(data.training)[1]      ## rows of data.training
  rnum = t(data.frame(sample(n, n, replace = TRUE)))    ## one row n column (random n integer), can repeat 
  i = 1
  repeat{
    
    rnum = rbind(rnum, sample(n, n, replace = TRUE))      ## add another one row (random n integer)
    i = i + 1                            ## finally, get n columns (batch*bootsnum+1)rows data
    if(i > (batch * bootsnum)) break()
  }
  rnum = rnum[-1,]      ## n columns (batch*bootsnum)rows data
  
 # i = 1
  if(regressor == "SVRrbf"){
    i = 1
  repeat {
    iteration1.1.boot = fn.boot.SVRrbf(data.training, data.virtual, rnum[((i-1)*bootsnum+1):(i*bootsnum),], bootsnum)   ### iteration1.1.boot consist of 41 columns predicted value from different training set 
    #    write.csv(iteration1.1.boot, paste0("boot_", i,".csv"), row.names=F)
    
    mean.error = cbind(iteration1.1.boot[,1], rowMeans(iteration1.1.boot), apply(iteration1.1.boot,1,var))   ### iteration1.1.boot[,1] based on all the n observations in data.training, no repeat
    colnames(mean.error) = c("predict","mean","var")
    predict = mean.error[,"predict"]
    mean.error = mean.error[,c("mean","var")]
    write.csv(mean.error, paste0("boot_", i,".csv"), row.names=F)
    
    i = i + 1
    if(i>batch) break()
  }
  }  
  
  if(regressor == "poly123121"){
  i = 1
    repeat {
      iteration1.1.boot = fn.boot.poly123121(data.training, data.virtual, rnum[((i-1)*bootsnum+1):(i*bootsnum),], bootsnum)
         # write.csv(iteration1.1.boot, paste0("boot_", i,".csv"), row.names=F)
      
      mean.error = cbind(iteration1.1.boot[,1], rowMeans(iteration1.1.boot), apply(iteration1.1.boot,1,var))
      colnames(mean.error) = c("predict","mean","var")
      predict = mean.error[,"predict"]
      mean.error = mean.error[, c("mean","var")]
      write.csv(mean.error, paste0("boot_", i,".csv"), row.names=F)
      
      i = i + 1
      if(i>batch) break()
    }
  }  

  
  if(regressor == "Gboosting"){
    i = 1
    repeat {
      iteration1.1.boot = fn.boot.Gboosting(data.training, data.virtual, rnum[((i-1)*bootsnum+1):(i*bootsnum),], bootsnum)
      # write.csv(iteration1.1.boot, paste0("boot_", i,".csv"), row.names=F)
      
      mean.error = cbind(iteration1.1.boot[,1], rowMeans(iteration1.1.boot), apply(iteration1.1.boot,1,var))
      colnames(mean.error) = c("predict","mean","var")
      predict = mean.error[,"predict"]
      mean.error = mean.error[,c("mean","var")]
      write.csv(mean.error, paste0("boot_", i,".csv"), row.names=F)
      
      i = i + 1
      if(i>batch) break()
    }
  }   
  
  i = 1
  #  boot = read.csv(paste0("boot_", i,".csv"))
  
  boot.temp = read.csv(paste0("boot_", i,".csv"))
  boot.mean = boot.temp[,1]
  boot.var = boot.temp[,2]
  
  
  i = i + 1
  repeat {
    #    boot.temp = read.csv(paste0("boot_", i,".csv"))
    #    boot = cbind(boot, boot.temp)
    
    boot.temp = read.csv(paste0("boot_", i,".csv"))
    boot.mean = cbind(boot.mean, boot.temp[,1])
    boot.var = cbind(boot.var, boot.temp[,2])
    
    print("read")
    
    i = i + 1
    if(i>batch) break()
  }
  
  
  # mean.error = fn.mean.error(boot)
  
  mean.error = cbind(predict, rowMeans(boot.mean), sqrt(rowMeans(boot.var) + apply(boot.mean,1,var)))   ###  is the algorithm for sd right?
  colnames(mean.error) = c("predict","mean","sd")
  
  
  return (data.frame(mean.error))
}

#fn.mean.error = function(data){
#  data = data.frame(data)
#  mean.error = cbind(data[,1], rowMeans(data), apply(data,1,sd))

#  colnames(mean.error) = c("predict","mean","sd")
#  return(data.frame(mean.error))
#}

# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #
# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #
# # # # # # # # # # # # Regression function for "devide into batch" # # # # # # # # # # # # # # # # # # # # 

#################################### SVRrbf ####################################
fn.boot.SVRrbf = function(data, data.virtual, rnum ,B) {  ### new function
  
  R = B-1    ### B: boostrap times
  
  parameter.svr.rbf = fn.cv.svr.rbf(data)  ### call funciton to boostrap
  gamma = parameter.svr.rbf[1] 
  cost = parameter.svr.rbf[2]
  model = svm(es ~ ., data = data, kernel = "radial", 
              gamma = gamma, cost = cost)
  
  predict.data = predict(model, data.virtual)   ### use all data in data.training  to boostrap, no repeat
  
  i=1
  repeat{
    boot.sample = rnum[i,]   ### choose ith row from rnum[((i-1)*bootsnum+1):(i*bootsnum)] rows, seen from the part divided into batch. In pratice, every integer in ith row represent one from n observation(data.training), can repeat   
    parameter.svr.rbf = fn.cv.svr.rbf(data[boot.sample,]) 
    gamma = parameter.svr.rbf[1]
    cost = parameter.svr.rbf[2]
    model = svm(es ~ ., data = data[boot.sample,], kernel = "radial", 
                gamma = gamma, cost = cost)
    predict.data = cbind(predict.data, predict(model, data.virtual))
    
    print(i)
    i=i+1
    if(i>B) break ()
  }
  return(data.frame(predict.data))
}
######################### poly123121 ######################
fn.boot.poly123121 = function(data, data.virtual, rnum ,B) {
  
  R = B-1
  
  predict.data = fn.model.poly.123121(data, data.virtual)
  
  q=1
  repeat{
    boot.sample = rnum[q,]
    t.data.training = data[boot.sample,]
    predict.data1 = fn.model.poly.123121(t.data.training, data.virtual)
    predict.data = cbind(predict.data, predict.data1)
    print(1)
    q=q+1
    if(q>B) break ()
    return(data.frame(predict.data))
  }
}
############################### Gboosting ################################

fn.boot.Gboosting = function(data, data.virtual, rnum ,B) {
  
  R = B-1
  
  predict.data = fn.model.Gboosting.6f(data, data.virtual)
  
  q=1
  repeat{
    boot.sample = rnum[q,]
    t.data.training = data[boot.sample,]
    predict.data1 = fn.model.Gboosting.6f(t.data.training, data.virtual)
    predict.data = cbind(predict.data, predict.data1)
    print(1)
    q=q+1
    if(q>B) break ()
    return(data.frame(predict.data))
  }
}


##################################################################################
################################# LOOCV ##########################################
fn.cverror = function(data.training,seed, regressor){  #### new function, can add anything
  set.seed(seed)                  
  n = dim(data.training)[1]         ###### rows of data.training 
  
  error = rep(n)         ##### creat n space to put error[i]
  if(regressor == "GB"){       
    i = 1
    repeat{
      predicted.value = fn.model.Gboosting.6f(data.training[-i,], data.training[i,])  #### predict data.training[i,] by data.training[-i,] with fucntion fn.model.Gboosting.6f 
      error[i] = predicted.value - data.training[i,"es"]    ### predict value mimus real value
      i = i + 1
      if(i > n) break()
    }
    
    error = error*error
    return(sum(error)/n)   
    
  }
  
  if(regressor == "poly123121"){
    i = 1
    repeat{
      predicted.value = fn.model.Gboosting.6f(data.training[-i,], data.training[i,])
      error[i] = predicted.value - data.training[i,"es"]
      i = i + 1
      if(i > n) break()
    }
    
    error = error*error
    return(sum(error)/n) 
    
  }
  
  if(regressor == "linear"){
    i = 1
    repeat{
      predicted.value = fn.model.Gboosting.6f(data.training[-i,], data.training[i,])
      error[i] = predicted.value - data.training[i,"es"]
      i = i + 1
      if(i > n) break()
    }
    
    error = error*error
    return(sum(error)/n) 
    
  }
  
  if(regressor == "RF"){       
    i = 1
    repeat{
      predicted.value = fn.model.rf(data.training[-i,], data.training[i,])  #### predict data.training[i,] by data.training[-i,] with fucntion fn.model.Gboosting.6f 
      error[i] = predicted.value - data.training[i,"es"]    ### predict value mimus real value
      i = i + 1
      if(i > n) break()
    }
    
    error = error*error
    return(sum(error)/n)   
    
  }
}




######################################################################################################
############################################### MSE.error ############################################

fn.MSE.error = function(data.model, data.training)
{
  n = dim(data.model)[1]
  error = data.training$es - data.model$mean
  return(sum(error*error)/n)
}


############################################################################
############################################################################
########################## KRR model ######################################

########## Parameters for Kernel
sigma <-  c(0.001, .01, .1, 1, 10, 100, 1000)
lambda <-  c(100, 10, 1, .1, .01, 0.001)

########## model for KRR
fn.krr = function(data.training, data.virtual){
  cv.error.loo = fn.k.fold.krr(15, data.training)
  #cv.error.loo = fn.loo.cv.krr(data.training)
  sigma = cv.error.loo$sigma
  lambda = cv.error.loo$lambda
  ########## Prepare the Gaussian RBF kernell & the ridge regression
  ##############################################################################
  ############ unit matrix ###########
  L = dim(data.training)[2]-1
  for (i in 1:length(sigma)) {
    for(j in 1:length(lambda)){
      N <- dim(data.training[, ])[1]
      Q = dim(data.virtual[, ])[1]
      # use features in data.training generate symmetric matrix
      #kk = as.matrix(data.training[, c(1:3)]) %*% t(as.matrix(data.training[, c(1:3)]))
      kk <- tcrossprod(as.matrix(data.training[, c(1:L)])) 
      dd <- diag(kk)
      ############ unit matrix ###########
      ident.N <- diag(rep(1,N))
      #######################
      ## Gaussian RBF kernel manually, (-matrix(dd,N,N)-t(matrix(dd,N,N))+2*kk) = ||xi-xj||^2
      ## standard guassian RBF kernel! Here myRBF.kernel is Q, matrix, not kernel function  ### 与下一句同样意义
      myRBF.kernel <- exp(sigma[i]*(-matrix(dd,N,N)-t(matrix(dd,N,N))+2*kk))
      #####
      alphas <- solve(myRBF.kernel + lambda[j]*ident.N)  #myRBF.kernel + lambda[j]*ident.N 的逆矩阵
      alphas <- alphas %*% data.training[, "es"]
      #### new kernel matrix for prediction
      kknew = as.matrix(data.virtual[, 1:L]) %*% as.matrix(t(data.training[, 1:L])) ## get x11*x12
      XXT = as.matrix(data.virtual[, 1:L]) %*% t(as.matrix(data.virtual[, 1:L]))  ## get x11^2 + x12^2
      Length.vector = t(matrix(dd, N, Q)) + diag(XXT)  ## get x11^2 + x12^2
      New.myRBF.kernel = exp(sigma[i]*(-(Length.vector)+2*kknew))  ## new kernel matrix
      data.virtual[, "Prediction"] = New.myRBF.kernel %*% alphas  ## make prediction
    }
  }
  return(data.virtual[, "Prediction"])
}






####################################################
########## cross validation ###########
#### leave one out
fn.loo.cv.krr = function(data.training){
  a = 0
  cv.error = data.frame(matrix(, 100, 3))
  colnames(cv.error) = c("cv.error", "sigma", "lambda")
  L = dim(data.training)[2]-1
  for (i in 1:length(sigma)) {
    for(j in 1:length(lambda)){
      N <- dim(data.training[, ])[1]
      for (m in 1:N) {
        # use features in data.training generate symmetric matrix
        #kk = as.matrix(data.training[, c(1:3)]) %*% t(as.matrix(data.training[, c(1:3)]))
        kk <- tcrossprod(as.matrix(data.training[-m, c(1:L)])) 
        dd <- diag(kk)
        ############ unit matrix ###########
        ident.N <- diag(rep(1,N-1))
        ## Gaussian RBF kernel manually, (-matrix(dd,N,N)-t(matrix(dd,N,N))+2*kk) = ||xi-xj||^2
        ## standard guassian RBF kernel! Here myRBF.kernel is K, matrix, not kernel function
        myRBF.kernel <- exp(sigma[i]*(-matrix(dd,N-1,N-1)-t(matrix(dd,N-1,N-1))+2*kk))
        #####
        alphas <- solve(myRBF.kernel + lambda[j]*ident.N)  #myRBF.kernel + lambda[j]*ident.N 的逆矩阵
        alphas <- alphas %*% data.training[-m, "es"]
        #### new kernel matrix for prediction
        kknew = as.matrix(data.training[m, 1:L]) %*% as.matrix(t(data.training[-m, 1:L])) ## get x11*x12
        XXT = as.matrix(data.training[m, 1:L]) %*% t(as.matrix(data.training[m, 1:L]))  ## get x11^2 + x12^2
        #Length.vector = dd + XXT
        Length.vector = t(matrix(dd, N-1, 1)) + diag(XXT)  ## get x11^2 + x12^2
        New.myRBF.kernel = exp(sigma[i]*(-(Length.vector)+2*kknew))  ## new kernel matrix
        data.training[m, "prediction"] = New.myRBF.kernel %*% alphas  # prediction
        data.training[m, "error"] = (data.training[m, "prediction"] - data.training[m, "es"])^2
      }
      a = a + 1
      cv.error[a, "cv.error"] = sum(data.training$error)/N
      cv.error[a, "sigma"] = sigma[i]
      cv.error[a, "lambda"] = lambda[j]
    }
  }
  cv.error = na.omit(cv.error)
  cv.error.best = cv.error[which.min(cv.error$cv.error), ]
  return(cv.error.best)
}


####################################################
########## cross validation ###########
########################## 10 fold

fn.k.fold.krr = function(K, data.training){
  #########################################
  ######### training data-随机分组 ########
  a = 1
  K = K  ### each group contain 23 samples
  D = seq (1, dim(data.training)[1], 1)
  num = matrix(, dim(data.training)[1]/K, K)
  repeat {
    num[a, ] = sample(D, K, replace = F)
    D.tem = c(num[a, ], D)
    D = D.tem[!duplicated(D.tem)]  ### 去掉已经选出去的元素D.tem
    D = D[-(1:K)]
    #    print(D)
    a = a + 1
    if (a*K > dim(data.training)[1]) break()
  }
  if(round(dim(data.training)[1]/K) == dim(data.training)[1]/K)  ### 判断行数能否整除K
    num = data.frame(num)
  if(round(dim(data.training)[1]/K) != dim(data.training)[1]/K) {
    num = data.frame(num) 
    length(D) = K ### 为了使用rbind命令，num与D应有一样的列数
    num = rbind(num, D)
  }
  
  ################## for KRR cross validation
  a = 0
  cv.error = data.frame(matrix(, 100, 3))
  colnames(cv.error) = c("cv.error", "sigma", "lambda")
  L = dim(data.training)[2]-1
  for (i in 1:length(sigma)) {
    for(j in 1:length(lambda)){
      N <- dim(data.training[, ])[1]
      for (m in 1:dim(num)[1]) {
        num.test = num[m, ]                         ## lines 38-40，去掉num中每行可能存在的NA， 利用complete.cases函数
        num.test = as.vector(as.numeric(num.test))  ## 将num的第m行从数据框转变为矢量
        num.test = num.test[complete.cases(num.test)]  ## 删除NA
        Q = length(num.test)
        # use features in data.training generate symmetric matrix
        #kk = as.matrix(data.training[, c(1:3)]) %*% t(as.matrix(data.training[, c(1:3)]))
        kk <- tcrossprod(as.matrix(data.training[-num.test, c(1:L)])) 
        dd <- diag(kk)
        ############ unit matrix ###########
        ident.N <- diag(rep(1,N-Q))
        #######################
        ## Gaussian RBF kernel manually, (-matrix(dd,N,N)-t(matrix(dd,N,N))+2*kk) = ||xi-xj||^2
        ## standard guassian RBF kernel! Here myRBF.kernel is Q, matrix, not kernel function  ### 与下一句同样意义
        myRBF.kernel <- exp(sigma[i]*(-matrix(dd,N-Q,N-Q)-t(matrix(dd,N-Q,N-Q))+2*kk))
        #####
        alphas <- solve(myRBF.kernel + lambda[j]*ident.N)  #myRBF.kernel + lambda[j]*ident.N 的逆矩阵
        alphas <- alphas %*% data.training[-num.test, "es"]
        #### new kernel matrix for prediction
        kknew = as.matrix(data.training[num.test, 1:L]) %*% as.matrix(t(data.training[-num.test, 1:L])) ## get x11*x12
        XXT = as.matrix(data.training[num.test, 1:L]) %*% t(as.matrix(data.training[num.test, 1:L]))  ## get x11^2 + x12^2
        Length.vector = t(matrix(dd, N-Q, Q)) + diag(XXT)  ## get x11^2 + x12^2
        New.myRBF.kernel = exp(sigma[i]*(-(Length.vector)+2*kknew))  ## new kernel matrix
        data.training[num.test, "Prediction"] = New.myRBF.kernel %*% alphas  ## make prediction
        data.training[num.test, "error"] = (data.training[num.test, "Prediction"]
                                            - data.training[num.test, "es"])^2
      }
      a = a + 1
      cv.error[a, "cv.error"] = sum(data.training$error)/dim(data.training)[1]
      cv.error[a, "sigma"] = sigma[i]
      cv.error[a, "lambda"] = lambda[j]
    }
  }
  cv.error = na.omit(cv.error)
  cv.error.best = cv.error[which.min(cv.error$cv.error), ]
  return(cv.error.best)
}


# ################ data #################
# setwd("C:/Users/yuanr/Desktop/KRR")
# data.raw = read.csv("data.training.csv")
# data.training = data.raw[, -1]
# data.training = data.training[-1, ]
# 
# ###### parameters used in fn.k.fold #########
# sigma <-  c(.01, .1, 1, 10, 100)
# lambda <-  c(10, 1, .1, .01)
# 
# ##### calculate cross validation error#############
# cv.error = fn.k.fold(10, sigma, lambda, data.training)


# ############# boostrap #############
# fn.boot.prop.mean.error = function(data.training, data.virtual,regressor,seed, B, property) {   ####### new function
#   set.seed(seed)
#   
#   n = dim(data.training)[1]
#   R = B-1                               ######## boostrap times
#   
#   if (regressor == "KRR") {     ####### used model 
#     predict.data = fn.krr(data.training,data.virtual)     ######## call function "fn.model.lm.6f", used all the observation
#     i=1
#     repeat{
#       # boot.sample = c(sample(n, 5, replace = FALSE), sample(n, n-5, replace = TRUE)) ## select 5 obvervation from n, replace=FALSE mean can't repeat, replace=TRUE can repeat 
#       boot.sample = sample(n, n, replace = TRUE)        ## select n integer from n, can repeat
#       t.data.training = data.training[boot.sample,]     ## data.training's boot.sample row
#       predict.data1 = fn.krr(t.data.training, data.virtual)  ## do regression use function just using observation in boot.sample
#       predict.data = cbind(predict.data, predict.data1)   ## add the predic.data1 to predict.data
#       i=i+1                                               ## repeat
#       print(i)
#       if(i>R) break ()
#     }
#   }
#   
#   
#   data.pre = cbind(rowMeans(predict.data), apply(predict.data,1,sd))
#   colnames(data.pre) = c("mean","sd")
#   return(data.frame(data.pre))
# }













