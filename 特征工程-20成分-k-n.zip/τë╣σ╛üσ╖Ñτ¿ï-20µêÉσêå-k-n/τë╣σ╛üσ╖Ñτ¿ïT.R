setwd("C:/Users/Administrator/Desktop/整理/2022记录/2022.10/R/相关性分析-20-k-n-T")
# library(randomForest)
# library(xgboost)
# library(neuralnet)
# library(e1071)
# library(corrplot)
# library(gbm)
# library(corrgram)
# library(psych)
# library(ggplot2)
# library(minerva)
# #source("functions.R")
# source('functions.new.R')

#Ƥ??ѷ?????Է???
data.raw.1 <- read.csv("k-归一化描述符.csv")
cor.pearson.1 <- data.frame(cor(data.raw.1,method = 'pearson'))
write.csv(cor.pearson.1, "k-归一化描述符-皮尔逊相关性分析.csv")

data.raw.2 <- read.csv("n-归一化描述符.csv")
cor.pearson.2 <- data.frame(cor(data.raw.2,method = 'pearson'))
write.csv(cor.pearson.2, "n-归一化描述符-皮尔逊相关性分析.csv")

# data.raw.3 <- read.csv("Q-??һ????????.csv")
# cor.pearson.3 <- data.frame(cor(data.raw.3,method = 'pearson'))
# write.csv(cor.pearson.3, "Q-??һ????????-Ƥ??ѷ?????Է???.csv")


#??Ҫ??????
#######
df <- data.raw.1
set.seed(1234)
train <- sample(nrow(df),1*nrow(df))
df.train <- df[train,]
table(df.train$es)
library(randomForest)
fit.forest<-randomForest(es~.,data=df.train,na.action=na.roughfix,importance=TRUE)
fit.forest
a<-data.frame(importance(fit.forest,type = 2))

write.csv(a,file = "k-归一化描述符-重要性排序.csv",row.names = TRUE)


#######
df <- data.raw.2
set.seed(1234)
train <- sample(nrow(df),1*nrow(df))
df.train <- df[train,]
table(df.train$es)
library(randomForest)
fit.forest<-randomForest(es~.,data=df.train,na.action=na.roughfix,importance=TRUE)
fit.forest
a<-data.frame(importance(fit.forest,type = 2))

write.csv(a,file = "n-归一化描述符-重要性排序.csv",row.names = TRUE)


#########
# df <- data.raw.3
# set.seed(1234)
# train <- sample(nrow(df),1*nrow(df))
# df.train <- df[train,]
# table(df.train$es)
# library(randomForest)
# fit.forest<-randomForest(es~.,data=df.train,na.action=na.roughfix,importance=TRUE)
# fit.forest
# a<-data.frame(importance(fit.forest,type = 2))
# 
# write.csv(a,file = "Q-??һ????????-??Ҫ??????.csv",row.names = TRUE)
# 



#?????ݹ?????

library(randomForest)
library(gbm)
library(e1071)
library(boot)



setwd("C:/Users/Administrator/Desktop/整理/2022记录/2022.10/R/相关性分析-20-k-n-T")
source("functions.R")
source("forward-subset.R")

data.raw<- read.csv("A-es??ɸѡ????.csv")
#data.raw <- data.raw.0[,-1]
dim(data.raw)
data.training.tem <- data.raw

data.training = cbind(data.training.tem[, 2:15], data.training.tem[, 1])
colnames(data.training)[15] = "es"
data.training$es

fn.backward.feature.cv(data.training, data.training, seed = 127, model = "rf", ntree = 5000)
#fn.backward.feature.cv(data.training, data.training, seed = 127, model = "svr", ntree)
#fn.backward.feature.cv(data.training, data.training, seed = 127, model = "gboosting", ntree)
#fn.backward.feature.cv(data.training, data.training, seed = 127, model = "krr", ntree)
#fn.backward.feature.cv(data.training, data.training, seed = 127, model = "linear", ntree)


###################################################################

library(randomForest)
library(neuralnet)
library(e1071)
library(corrplot)
library(gbm)
source("functions.R")

setwd("C:/Users/Administrator/Desktop/123")
data.del.zero <- read.csv("Q-es+1????.csv")
data.del.zero <- data.del.zero[1:12,]
n = dim(data.del.zero)[1]
set.seed(1990)
index = sample(n, round(1*n), replace = F)
data.train = data.del.zero[index, ]
#data.test = data.del.zero[-index, ]

#?}?}?}?}?}?}?}?}?}?}SVM
set.seed(101)
svr.train = fn.boot.prop.mean.error(data.train, data.train,
                                    "SVR.rbf", 101,3, es)
#svr.test = fn.boot.prop.mean.error(data.train, data.test,
                                   # "SVR.rbf", 101, 3, es)

plot(data.train$es, svr.train$mean, xlim = c(10000, 20000), ylim = c(10000, 20000), xlab = "measured", ylab = "predicted", main = "SVR.rbf")
abline(0, 1, col = "red")
points(data.test$es, svr.test$mean, col = "red")
legend('bottomright',legend=c('training','test'), pch=18, col=c('black','red'))
cor(data.train$es, svr.train$mean)^2
#write.csv(svr.train$mean,file = "SVM01.csv",row.names = TRUE)
#write.csv(svr.test$mean,file = "SVM02.csv",row.names = TRUE)





















