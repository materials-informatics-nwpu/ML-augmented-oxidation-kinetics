##########################################
################ forward subset selection ############
#####################################################################
## 程序感悟???
## 写循环时，一定要注意循环变量的命名；循环变量的名字不要与变量i扯上关系，不然会增加程序编写的复杂程???
## 所谓循环，那么一个循环输出的变量要能在下一个循环中用起来，即变量名不变，内容随循环迭代更新
## 中间变量的名字，要简洁清晰，更重要的是普适???

####################### ---leave one out cv error---########################
fn.backward.feature.cv = function(data.train, data.virtual, seed, model, ntree){
  if(model == "rf"){  
    rows = dim(data.train)[2]-1
    names.feature = colnames(data.train)[1:rows] #数据data.train的列名字
    cverror = data.frame(matrix(, rows, 2)) 
    colnames(cverror) = c("feature", "cverror")
    for (i in 1:rows) { ### 仅有一个特征，选取最佳的单个特征
      data.training = data.train[, c(names.feature[i], "es")] #选取data.train中的第i列作为特???
      feature.num = dim(data.training)[2]-1 # 新数据data.training中特征的数量，除了目标性能，均为特???
      error.cv = fn.cverror(data.training, seed, model, ntree, mtry = feature.num)
      cverror[i, ] = cbind(names.feature[i], error.cv) ## 每个特征对应的cverror
            print(cverror[i, ])
    }
    write.csv(cverror, paste0("cverror.rf", 1, ".csv"))
    j = 1    ## 从至少两个特征开始，进行迭代，每次增加最关键的特征，直至特征组合包括所有特???
    repeat{ 
      #cverror = get(paste0("cverror.", j))
      feature.select = cverror[which.min(cverror[, 2]), 1] # cverror中最佳的特征（单个特征，上面for循环所得）或特征组合（repeat开始），即对应最小的预测误差，特征组合格式为“NCT+NTO???
      feature.select.tem = unlist(strsplit(feature.select, "[,]")) ## 利用split和list函数将“NCT+NTO”拆分为“NCT??? “NTO???
      number.feature = sum(table(feature.select.tem)) ## 最佳特征组合的size，numer.feature对应新增的最佳特征位???
      names.feature = names.feature[-which(names.feature == feature.select.tem[number.feature])] ## 从列名字中去除上次得到的一个最佳特征，每次迭代去除一???
      rows = dim(data.train)[2]-number.feature-1 ## error存储所需的行数逐次减少
      cverror = data.frame(matrix(, rows, 2)) 
      colnames(cverror) = c("feature", "cverror")
      for (i in 1:rows) { ## 特征组合中数目固定，选择其中最佳的组合
        data.training = data.train[, c(feature.select.tem, names.feature[i], "es")] ## 在此前选择最佳特征或特征组合的基础上，对比新增names.feature中的每一个特征，对cverror的影???
        feature.num = dim(data.training)[2]-1 ## 随机森林模型，节点属性的数量，mtry
        error.cv = fn.cverror(data.training, seed, model, ntree, mtry = feature.num)
        cverror[i, ] = cbind(paste0(feature.select, "," , names.feature[i]), error.cv) ## 更新cverror,第一列feature的形式为“NCT+NTO+evw???
        #        print(cverror[i, ])
      }
      j = j + 1
      print(j)
      write.csv(cverror, paste0("cverror.rf", j, ".csv"))
      if(j >= dim(data.train)[2]-1) break()
    }
  }
  
  if(model == "svr"){
    rows = dim(data.train)[2]-1
    names.feature = colnames(data.train)[1:rows]
    cverror = data.frame(matrix(, rows, 2)) 
    colnames(cverror) = c("feature", "cverror")
    for (i in 1:rows) {
      data.training = data.train[, c(names.feature[i], "es")]
      feature.num = dim(data.training)[2]-1
      error.cv = fn.cverror(data.training, seed, model, ntree, mtry = feature.num)
      cverror[i, ] = cbind(names.feature[i], error.cv)
            print(cverror[i, ])
    }
    write.csv(cverror, paste0("cverror.svr", 1, ".csv"))
    j = 1
    repeat{
      #cverror = get(paste0("cverror.", j))
      feature.select = cverror[which.min(cverror[, 2]), 1]
      feature.select.tem = unlist(strsplit(feature.select, "[,]"))
      number.feature = sum(table(feature.select.tem))
      names.feature = names.feature[-which(names.feature == feature.select.tem[number.feature])]
      rows = dim(data.train)[2]-number.feature-1
      cverror = data.frame(matrix(, rows, 2)) 
      colnames(cverror) = c("feature", "cverror")
      for (i in 1:rows) {
        data.training = data.train[, c(feature.select.tem, names.feature[i], "es")]
        feature.num = dim(data.training)[2]-1
        error.cv = fn.cverror(data.training, seed, model, ntree, mtry = feature.num)
        cverror[i, ] = cbind(paste0(feature.select, "," , names.feature[i]), error.cv)
        #        print(cverror[i, ])
      }
      j = j + 1
      print(j)
      write.csv(cverror, paste0("cverror.svr", j, ".csv"))
      if(j >= dim(data.train)[2]-1) break()
    }
  }
  
  if(model == "gboosting"){
    rows = dim(data.train)[2]-1
    names.feature = colnames(data.train)[1:rows]
    cverror = data.frame(matrix(, rows, 2)) 
    colnames(cverror) = c("feature", "cverror")
    for (i in 1:rows) {
      data.training = data.train[, c(names.feature[i], "es")]
      feature.num = dim(data.training)[2]-1
      error.cv = fn.cverror(data.training, seed, model, ntree, mtry = feature.num)
      cverror[i, ] = cbind(names.feature[i], error.cv)
            print(cverror[i, ])
    }
    write.csv(cverror, paste0("cverror.gboost", 1, ".csv"))
    j = 1
    repeat{
      #cverror = get(paste0("cverror.", j))
      feature.select = cverror[which.min(cverror[, 2]), 1]
      feature.select.tem = unlist(strsplit(feature.select, "[,]"))
      number.feature = sum(table(feature.select.tem))
      names.feature = names.feature[-which(names.feature == feature.select.tem[number.feature])]
      rows = dim(data.train)[2]-number.feature-1
      cverror = data.frame(matrix(, rows, 2)) 
      colnames(cverror) = c("feature", "cverror")
      for (i in 1:rows) {
        data.training = data.train[, c(feature.select.tem, names.feature[i], "es")]
        feature.num = dim(data.training)[2]-1
        error.cv = fn.cverror(data.training, seed, model, ntree, mtry = feature.num)
        cverror[i, ] = cbind(paste0(feature.select, "," , names.feature[i]), error.cv)
        #        print(cverror[i, ])
      }
      j = j + 1
      print(j)
      write.csv(cverror, paste0("cverror.gboost", j, ".csv"))
      if(j >= dim(data.train)[2]-1) break()
    }
  }
  
  
  if(model == "krr"){
    rows = dim(data.train)[2]-1
    names.feature = colnames(data.train)[1:rows]
    cverror = data.frame(matrix(, rows, 2)) 
    colnames(cverror) = c("feature", "cverror")
    for (i in 1:rows) {
      data.training = data.train[, c(names.feature[i], "es")]
      #feature.num = dim(data.training)[2]-1
      error.cv = fn.loo.cv.krr(data.training)
      cverror[i, ] = cbind(names.feature[i], error.cv$cv.error) ## error.cv包括cv.error, 还有krr模型的超参数lambda???
           print(cverror[i, ])
    }
    write.csv(cverror, paste0("cverror.krr", 1, ".csv"))
    j = 1
    repeat{
      #cverror = get(paste0("cverror.", j))
      feature.select = cverror[which.min(cverror[, 2]), 1]
      feature.select.tem = unlist(strsplit(feature.select, "[,]"))
      number.feature = sum(table(feature.select.tem))
      names.feature = names.feature[-which(names.feature == feature.select.tem[number.feature])]
      rows = dim(data.train)[2]-number.feature-1
      cverror = data.frame(matrix(, rows, 2)) 
      colnames(cverror) = c("feature", "cverror")
      for (i in 1:rows) {
        data.training = data.train[, c(feature.select.tem, names.feature[i], "es")]
        feature.num = dim(data.training)[2]-1
        error.cv = fn.loo.cv.krr(data.training)
        cverror[i, ] = cbind(paste0(feature.select, "," , names.feature[i]), error.cv$cv.error)
        #        print(cverror[i, ])
      }
      j = j + 1
      print(j)
      write.csv(cverror, paste0("cverror.krr", j, ".csv"))
      if(j >= dim(data.train)[2]-1) break()
    }
  }
  
  if(model == "linear"){
    rows = dim(data.train)[2]-1
    names.feature = colnames(data.train)[1:rows]
    cverror = data.frame(matrix(, rows, 2)) 
    colnames(cverror) = c("feature", "cverror")
    for (i in 1:rows) {
      data.training = data.train[, c(names.feature[i], "es")]
      feature.num = dim(data.training)[2]-1
      error.cv = fn.cverror(data.training, seed, model, ntree, mtry = feature.num)
      cverror[i, ] = cbind(names.feature[i], error.cv)
      print(cverror[i, ])
    }
    write.csv(cverror, paste0("cverror.linear", 1, ".csv"))
    j = 1
    repeat{
      #cverror = get(paste0("cverror.", j))
      feature.select = cverror[which.min(cverror[, 2]), 1]
      feature.select.tem = unlist(strsplit(feature.select, "[,]"))
      number.feature = sum(table(feature.select.tem))
      names.feature = names.feature[-which(names.feature == feature.select.tem[number.feature])]
      rows = dim(data.train)[2]-number.feature-1
      cverror = data.frame(matrix(, rows, 2)) 
      colnames(cverror) = c("feature", "cverror")
      for (i in 1:rows) {
        data.training = data.train[, c(feature.select.tem, names.feature[i], "es")]
        feature.num = dim(data.training)[2]-1
        error.cv = fn.cverror(data.training, seed, model, ntree, mtry = feature.num)
        cverror[i, ] = cbind(paste0(feature.select, "," , names.feature[i]), error.cv)
        #        print(cverror[i, ])
      }
      j = j + 1
      print(j)
      write.csv(cverror, paste0("cverror.linear", j, ".csv"))
      if(j >= dim(data.train)[2]-1) break()
    }
  }
}



####################### ---mean squared error---########################
#####################################################################
fn.backward.feature.mse = function(data.train, data.virtual, seed, model, B, ntree){
  if(model == "rf"){
    names.feature = colnames(data.train)[1:18]
    rows = dim(data.train)[2]-1
    cverror = data.frame(matrix(, rows, 2)) 
    colnames(cverror) = c("feature", "cverror")
    for (i in 1:rows) {
      data.training = data.train[, c(names.feature[i], "es")]
      feature.num = dim(data.training)[2]-1
      #error.cv = fn.cverror(data.training, seed, model, ntree, mtry = feature.num)
      error.mse = fn.mse.error(data.training, data.training, seed, model, B, ntree, mtry = feature.num)
      cverror[i, ] = cbind(names.feature[i], error.mse)
      print(cverror[i, ])
    }
    write.csv(cverror, paste0("mse.rf", 1, ".csv"))
    j = 1
    repeat{
      #cverror = get(paste0("cverror.", j))
      feature.select = cverror[which.min(cverror[, 2]), 1]
      feature.select.tem = unlist(strsplit(feature.select, "[,]"))
      number.feature = sum(table(feature.select.tem))
      names.feature = names.feature[-which(names.feature == feature.select.tem[number.feature])]
      rows = dim(data.train)[2]-number.feature-1
      cverror = data.frame(matrix(, rows, 2)) 
      colnames(cverror) = c("feature", "cverror")
      for (i in 1:rows) {
        data.training = data.train[, c(feature.select.tem, names.feature[i], "es")]
        feature.num = dim(data.training)[2]-1
        #error.cv = fn.cverror(data.training, seed, model, ntree, mtry = feature.num)
        error.mse = fn.mse.error(data.training, data.training, seed, model, B, ntree, mtry = feature.num)
        cverror[i, ] = cbind(paste0(feature.select, "," , names.feature[i]), error.mse)
        #        print(cverror[i, ])
      }
      j = j + 1
      print(j)
      write.csv(cverror, paste0("mse.rf", j, ".csv"))
      if(j >= dim(data.train)[2]-1) break()
    }
  }
  
  if(model == "svr"){
    names.feature = colnames(data.train)[1:18]
    rows = dim(data.train)[2]-1
    cverror = data.frame(matrix(, rows, 2)) 
    colnames(cverror) = c("feature", "cverror")
    for (i in 1:rows) {
      data.training = data.train[, c(names.feature[i], "es")]
      feature.num = dim(data.training)[2]-1
      #error.cv = fn.cverror(data.training, seed, model, ntree, mtry = feature.num)
      error.mse = fn.mse.error(data.training, data.training, seed, model, B, ntree, mtry = feature.num)
      cverror[i, ] = cbind(names.feature[i], error.mse)
      print(cverror[i, ])
    }
    write.csv(cverror, paste0("mse.svr", 1, ".csv"))
    j = 1
    repeat{
      #cverror = get(paste0("cverror.", j))
      feature.select = cverror[which.min(cverror[, 2]), 1]
      feature.select.tem = unlist(strsplit(feature.select, "[,]"))
      number.feature = sum(table(feature.select.tem))
      names.feature = names.feature[-which(names.feature == feature.select.tem[number.feature])]
      rows = dim(data.train)[2]-number.feature-1
      cverror = data.frame(matrix(, rows, 2)) 
      colnames(cverror) = c("feature", "cverror")
      for (i in 1:rows) {
        data.training = data.train[, c(feature.select.tem, names.feature[i], "es")]
        feature.num = dim(data.training)[2]-1
        #error.cv = fn.cverror(data.training, seed, model, ntree, mtry = feature.num)
        error.mse = fn.mse.error(data.training, data.training, seed, model, B, ntree, mtry = feature.num)
        cverror[i, ] = cbind(paste0(feature.select, "," , names.feature[i]), error.mse)
        #        print(cverror[i, ])
      }
      j = j + 1
      print(j)
      write.csv(cverror, paste0("mse.svr", j, ".csv"))
      if(j >= dim(data.train)[2]-1) break()
    }
  }
  
  if(model == "gboosting"){
    names.feature = colnames(data.train)[1:18]
    rows = dim(data.train)[2]-1
    cverror = data.frame(matrix(, rows, 2)) 
    colnames(cverror) = c("feature", "cverror")
    for (i in 1:rows) {
      data.training = data.train[, c(names.feature[i], "es")]
      feature.num = dim(data.training)[2]-1
      #error.cv = fn.cverror(data.training, seed, model, ntree, mtry = feature.num)
      error.mse = fn.mse.error(data.training, data.training, seed, model, B, ntree, mtry = feature.num)
      cverror[i, ] = cbind(names.feature[i], error.mse)
      print(cverror[i, ])
    }
    write.csv(cverror, paste0("mse.gboost", 1, ".csv"))
    j = 1
    repeat{
      #cverror = get(paste0("cverror.", j))
      feature.select = cverror[which.min(cverror[, 2]), 1]
      feature.select.tem = unlist(strsplit(feature.select, "[,]"))
      number.feature = sum(table(feature.select.tem))
      names.feature = names.feature[-which(names.feature == feature.select.tem[number.feature])]
      rows = dim(data.train)[2]-number.feature-1
      cverror = data.frame(matrix(, rows, 2)) 
      colnames(cverror) = c("feature", "cverror")
      for (i in 1:rows) {
        data.training = data.train[, c(feature.select.tem, names.feature[i], "es")]
        feature.num = dim(data.training)[2]-1
        #error.cv = fn.cverror(data.training, seed, model, ntree, mtry = feature.num)
        error.mse = fn.mse.error(data.training, data.training, seed, model, B, ntree, mtry = feature.num)
        cverror[i, ] = cbind(paste0(feature.select, "," , names.feature[i]), error.mse)
        #        print(cverror[i, ])
      }
      j = j + 1
      print(j)
      write.csv(cverror, paste0("mse.gboost", j, ".csv"))
      if(j >= dim(data.train)[2]-1) break()
    }
  }
  
  
  if(model == "krr"){
    names.feature = colnames(data.train)[1:18]
    rows = dim(data.train)[2]-1
    cverror = data.frame(matrix(, rows, 2)) 
    colnames(cverror) = c("feature", "cverror")
    for (i in 1:rows) {
      data.training = data.train[, c(names.feature[i], "es")]
      #feature.num = dim(data.training)[2]-1
      #error.cv = fn.loo.cv.krr(data.training)
      error.mse = fn.mse.error(data.training, data.training, seed, model, B, ntree, mtry = feature.num)
      cverror[i, ] = cbind(names.feature[i], error.mse)
      print(cverror[i, ])
    }
    write.csv(cverror, paste0("mse.krr", 1, ".csv"))
    j = 1
    repeat{
      #cverror = get(paste0("cverror.", j))
      feature.select = cverror[which.min(cverror[, 2]), 1]
      feature.select.tem = unlist(strsplit(feature.select, "[,]"))
      number.feature = sum(table(feature.select.tem))
      names.feature = names.feature[-which(names.feature == feature.select.tem[number.feature])]
      rows = dim(data.train)[2]-number.feature-1
      cverror = data.frame(matrix(, rows, 2)) 
      colnames(cverror) = c("feature", "cverror")
      for (i in 1:rows) {
        data.training = data.train[, c(feature.select.tem, names.feature[i], "es")]
        feature.num = dim(data.training)[2]-1
        #error.cv = fn.loo.cv.krr(data.training)
        error.mse = fn.mse.error(data.training, data.training, seed, model, B, ntree, mtry = feature.num)
        cverror[i, ] = cbind(paste0(feature.select, "," , names.feature[i]), error.mse)
        #        print(cverror[i, ])
      }
      j = j + 1
      print(j)
      write.csv(cverror, paste0("mse.krr", j, ".csv"))
      if(j >= dim(data.train)[2]-1) break()
    }
  }
  
  if(model == "linear"){
    names.feature = colnames(data.train)[1:18]
    rows = dim(data.train)[2]-1
    cverror = data.frame(matrix(, rows, 2)) 
    colnames(cverror) = c("feature", "cverror")
    for (i in 1:rows) {
      data.training = data.train[, c(names.feature[i], "es")]
      feature.num = dim(data.training)[2]-1
      #error.cv = fn.cverror(data.training, seed, model, ntree, mtry = feature.num)
      error.mse = fn.mse.error(data.training, data.training, seed, model, B, ntree, mtry = feature.num)
      cverror[i, ] = cbind(names.feature[i], error.mse)
      print(cverror[i, ])
    }
    write.csv(cverror, paste0("mse.linear", 1, ".csv"))
    j = 1
    repeat{
      #cverror = get(paste0("cverror.", j))
      feature.select = cverror[which.min(cverror[, 2]), 1]
      feature.select.tem = unlist(strsplit(feature.select, "[,]"))
      number.feature = sum(table(feature.select.tem))
      names.feature = names.feature[-which(names.feature == feature.select.tem[number.feature])]
      rows = dim(data.train)[2]-number.feature-1
      cverror = data.frame(matrix(, rows, 2)) 
      colnames(cverror) = c("feature", "cverror")
      for (i in 1:rows) {
        data.training = data.train[, c(feature.select.tem, names.feature[i], "es")]
        feature.num = dim(data.training)[2]-1
        #error.cv = fn.cverror(data.training, seed, model, ntree, mtry = feature.num)
        error.mse = fn.mse.error(data.training, data.training, seed, model, B, ntree, mtry = feature.num)
        cverror[i, ] = cbind(paste0(feature.select, "," , names.feature[i]), error.mse)
        #        print(cverror[i, ])
      }
      j = j + 1
      print(j)
      write.csv(cverror, paste0("mse.linear", j, ".csv"))
      if(j >= dim(data.train)[2]-1) break()
    }
  }
}