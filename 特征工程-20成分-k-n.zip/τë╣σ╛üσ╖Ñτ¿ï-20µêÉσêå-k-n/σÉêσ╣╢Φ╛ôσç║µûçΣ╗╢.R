
# library(readr)
# library(data.table)
# 
# dir = "E:/硕士论文流程/调研/难熔高熵合金/数据/RHEAs-课题/RHEAs-ML模型/linear-forward-subset/linear-forward-subset"  # 搜索指定文件夹下文件，……填写为你的文件夹路径，注意使用/做目录分隔符
# #获得csv文件列表
# file_list = list.files(path = dir, pattern = "*.csv$",recursive = TRUE,full.names = TRUE)  #获得csv文件列表     
# #生成新的存储地址，用于csv文件存储。为dir的上层目录，也可以自行修改paste(dir,"new.csv")部分为绝对路径
# store_csv = paste(dir,"new.csv")       
# 
# for(i in 1:length(file_list)) {    #循环绝对地址的列表
#   df = fread(file = file_list[i],encoding = 'UTF-8')         #读取csv文件
#   #如果不存在csv文件则创建，追加写入新csv文件
#   write_csv(df,path = store_csv,append = TRUE, col_names = FALSE)              
#   
# }

setwd("E:/硕士论文流程/RHEAs高温强度/特征筛选/1000RT-皮尔逊特征筛选-向后特获筛选/HEAS.1000HT.向后特征子集筛选/linear.backward")
data.1 <- read.csv('cverror.linear1.csv')
data.2 <- read.csv('cverror.linear2.csv')
data.3 <- read.csv('cverror.linear3.csv')
data.4 <- read.csv('cverror.linear4.csv')
data.5 <- read.csv('cverror.linear5.csv')
data.6 <- read.csv('cverror.linear6.csv')
data.7 <- read.csv('cverror.linear7.csv')
data.8 <- read.csv('cverror.linear8.csv')
data.9 <- read.csv('cverror.linear9.csv')
data.10 <- read.csv('cverror.linear10.csv')
data.11 <- read.csv('cverror.linear11.csv')
data.12 <- read.csv('cverror.linear12.csv')
data.13 <- read.csv('cverror.linear13.csv')
data.14 <- read.csv('cverror.linear14.csv')
data.15 <- read.csv('cverror.linear15.csv')
data.16 <- read.csv('cverror.linear16.csv')
data.17 <- read.csv('cverror.linear17.csv')
data.18 <- read.csv('cverror.linear18.csv')
data.19 <- read.csv('cverror.linear19.csv')
data.20 <- read.csv('cverror.linear20.csv')
data.21 <- read.csv('cverror.linear21.csv')
data.22 <- read.csv('cverror.linear22.csv')
# data.23 <- read.csv('cverror.svr23.csv')
# data.24 <- read.csv('cverror.svr24.csv')
# data.25 <- read.csv('cverror.svr25.csv')
# data.26 <- read.csv('cverror.svr26.csv')
# data.27 <- read.csv('cverror.svr27.csv')
# data.28 <- read.csv('cverror.svr28.csv')
# data.29 <- read.csv('cverror.svr29.csv')
# data.30 <- read.csv('cverror.linear30.csv')
# data.31 <- read.csv('cverror.linear31.csv')
# data.32 <- read.csv('cverror.linear32.csv')
# data.33 <- read.csv('cverror.linear33.csv')
# data.34 <- read.csv('cverror.linear34.csv')
# data.35 <- read.csv('cverror.linear35.csv')
# data.36 <- read.csv('cverror.linear36.csv')
# data.37 <- read.csv('cverror.linear37.csv')
# data.38 <- read.csv('cverror.linear38.csv')
# data.39 <- read.csv('cverror.linear39.csv')
# data.40 <- read.csv('cverror.linear40.csv')
# data.41 <- read.csv('cverror.linear41.csv')
# data.42 <- read.csv('cverror.linear42.csv')
# data.43 <- read.csv('cverror.linear43.csv')
# data.44 <- read.csv('cverror.linear44.csv')
# data.45 <- read.csv('cverror.linear45.csv')
# data.46 <- read.csv('cverror.linear46.csv')
# data.47 <- read.csv('cverror.linear47.csv')
# data.48 <- read.csv('cverror.linear48.csv')
# data.49 <- read.csv('cverror.linear49.csv')
# data.50 <- read.csv('cverror.linear50.csv')
# data.51 <- read.csv('cverror.linear51.csv')
# data.52 <- read.csv('cverror.linear52.csv')
# data.53 <- read.csv('cverror.linear53.csv')
# data.54 <- read.csv('cverror.linear54.csv')
# data.55 <- read.csv('cverror.linear55.csv')
# data.56 <- read.csv('cverror.linear56.csv')
# data.57 <- read.csv('cverror.linear57.csv')
# data.58 <- read.csv('cverror.linear58.csv')
# data.59 <- read.csv('cverror.linear59.csv')
# data.60 <- read.csv('cverror.linear60.csv')
# data.61 <- read.csv('cverror.linear61.csv')
data.all <- rbind(data.1,data.2,data.3,data.4,data.5,data.6,data.7,data.8,data.9,data.10,
                  data.11,data.12,data.13,data.14,data.15,data.16,data.17,data.18,data.19,data.20,
                  data.21,data.22)#,data.23,data.24,data.25,data.26,data.27,data.28,data.29)#,data.30,
                  # data.31,data.32,data.33,data.34,data.35,data.36,data.37,data.38,data.39,data.40,
                  # data.41,data.42,data.43,data.44,data.45,data.46,data.47,data.48,data.49,data.50,
                  # data.51,data.52,data.53,data.54,data.55,data.56,data.57,data.58,data.59,data.60,
                  # data.61)
write.csv(data.all,'cverror.linear.all.csv')
#####相同特征数量下，cverror最小的一项
data.min.1 <- data.1[which.min(data.1$cverror),]
data.min.2 <- data.2[which.min(data.2$cverror),]
data.min.3 <- data.3[which.min(data.3$cverror),]
data.min.4 <- data.4[which.min(data.4$cverror),]
data.min.5 <- data.5[which.min(data.5$cverror),]
data.min.6 <- data.6[which.min(data.6$cverror),]
data.min.7 <- data.7[which.min(data.7$cverror),]
data.min.8 <- data.8[which.min(data.8$cverror),]
data.min.9 <- data.9[which.min(data.9$cverror),]
data.min.10 <- data.10[which.min(data.10$cverror),]
data.min.11 <- data.11[which.min(data.11$cverror),]
data.min.12 <- data.12[which.min(data.12$cverror),]
data.min.13 <- data.13[which.min(data.13$cverror),]
data.min.14 <- data.14[which.min(data.14$cverror),]
data.min.15 <- data.15[which.min(data.15$cverror),]
data.min.16 <- data.16[which.min(data.16$cverror),]
data.min.17 <- data.17[which.min(data.17$cverror),]
data.min.18 <- data.18[which.min(data.18$cverror),]
data.min.19 <- data.19[which.min(data.19$cverror),]
data.min.20 <- data.20[which.min(data.20$cverror),]
data.min.21 <- data.21[which.min(data.21$cverror),]
data.min.22 <- data.22[which.min(data.22$cverror),]
# data.min.23 <- data.23[which.min(data.23$cverror),]
# data.min.24 <- data.24[which.min(data.24$cverror),]
# data.min.25 <- data.25[which.min(data.25$cverror),]
# data.min.26 <- data.26[which.min(data.26$cverror),]
# data.min.27 <- data.27[which.min(data.27$cverror),]
# data.min.28 <- data.28[which.min(data.28$cverror),]
# data.min.29 <- data.29[which.min(data.29$cverror),]
# data.min.30 <- data.30[which.min(data.30$cverror),]
# data.min.31 <- data.31[which.min(data.31$cverror),]
# data.min.32 <- data.32[which.min(data.32$cverror),]
# data.min.33 <- data.33[which.min(data.33$cverror),]
# data.min.34 <- data.34[which.min(data.34$cverror),]
# data.min.35 <- data.35[which.min(data.35$cverror),]
# data.min.36 <- data.36[which.min(data.36$cverror),]
# data.min.37 <- data.37[which.min(data.37$cverror),]
# data.min.38 <- data.38[which.min(data.38$cverror),]
# data.min.39 <- data.39[which.min(data.39$cverror),]
# data.min.40 <- data.40[which.min(data.40$cverror),]
# data.min.41 <- data.41[which.min(data.41$cverror),]
# data.min.42 <- data.42[which.min(data.42$cverror),]
# data.min.43 <- data.43[which.min(data.43$cverror),]
# data.min.44 <- data.44[which.min(data.44$cverror),]
# data.min.45 <- data.45[which.min(data.45$cverror),]
# data.min.46 <- data.46[which.min(data.46$cverror),]
# data.min.47 <- data.47[which.min(data.47$cverror),]
# data.min.48 <- data.48[which.min(data.48$cverror),]
# data.min.49 <- data.49[which.min(data.49$cverror),]
# data.min.50 <- data.50[which.min(data.50$cverror),]
# data.min.51 <- data.51[which.min(data.51$cverror),]
# data.min.52 <- data.52[which.min(data.52$cverror),]
# data.min.53 <- data.53[which.min(data.53$cverror),]
# data.min.54 <- data.54[which.min(data.54$cverror),]
# data.min.55 <- data.55[which.min(data.55$cverror),]
# data.min.56 <- data.56[which.min(data.56$cverror),]
# data.min.57 <- data.57[which.min(data.57$cverror),]
# data.min.58 <- data.58[which.min(data.58$cverror),]
# data.min.59 <- data.59[which.min(data.59$cverror),]
# data.min.60 <- data.60[which.min(data.60$cverror),]
# data.min.61 <- data.61[which.min(data.61$cverror),]
data.min.all <- rbind(data.min.1,data.min.2,data.min.3,data.min.4,data.min.5,data.min.6,data.min.7,data.min.8,data.min.9,data.min.10,
                      data.min.11,data.min.12,data.min.13,data.min.14,data.min.15,data.min.16,data.min.17,data.min.18,data.min.19,data.min.20,
                      data.min.21,data.min.22)#,data.min.23,data.min.24,data.min.25,data.min.26,data.min.27,data.min.28,data.min.29)#,data.min.30,
                      # data.min.31,data.min.32,data.min.33,data.min.34,data.min.35,data.min.36,data.min.37,data.min.38,data.min.39,data.min.40,
                      # data.min.41,data.min.42,data.min.43,data.min.44,data.min.45,data.min.46,data.min.47,data.min.48,data.min.49,data.min.50,
                      # data.min.51,data.min.52,data.min.53,data.min.54,data.min.55,data.min.56,data.min.57,data.min.58,data.min.59,data.min.60,
                      # data.min.61)
write.csv(data.min.all,'cverror.linear.all.min.csv')
