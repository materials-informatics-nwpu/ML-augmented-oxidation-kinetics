
##### load library #####
library(randomForest)
#library(randomForestCI)
#library(vcd)
#library(corrgram)
#library(leaps) # for subset selection
#library(glmnet) # for lasso
library(gbm) # for grediant boosting
#library(matrixStats) # for rowSds
library(e1071) # the e1071 library contains implementations for a number of statistical learning methods.
library(boot) # for bootstrap

##### load functions #####
setwd("E:/硕士论文流程/RHEAs高温强度/特征筛选/1000RT-皮尔逊特征筛选-向后特获筛选/HEAS.1000HT.向后特征子集筛选")
#source("Features-ceramic-NEW-NCT.R")
#source("Features-ceramic.R")
source("functions.R")
source("forward-subset.R")

##### load data #####
#rawdata = read.csv("HEA.csv")
#data.training.tem = na.omit(rawdata)
data.raw.0 <- read.csv("RHEAs.1000HT.feature.Pearson剩余22.csv")
#data.raw.1 <- data.raw.0[,14:76]
#data.raw.2 <- data.frame(data.raw.0[,77])
#data.raw <- cbind(data.raw.2,data.raw.1)
#colnames(data.raw) = c('es','D1','D2','D3','D4','D5','D6','D7','D8','D9','D10',
#                       'D11','D12','D13','D14','D15','D16','D17','D18','D19','D20',
#                       'D21','D22','D23','D24','D25','D26','D27','D28','D29','D30',
#                       'D31','D32','D33','D34','D35','D36','D37','D38','D39','D40',
#                       'D41','D42','D43','D44','D45','D46','D47','D48','D49','D50',
#                       'D51','D52','D53','D54','D55','D56','D57','D58','D59','D60',
#                       'D61','D62','D63') ##zs-es代表性质列
#data.raw <- data.raw[,c(-38,-39)]
#dim(data.raw)
######按照随机森林重要性对Pearson>0.8的特征进行筛选,剩余5个
#D34,D33,D13,D52,D26,D62,D50,D6,D61,D8,D4,D47,D45,D24,D54,D49,D3,D22, D16,D42,D44,D32,D12,D18,D41
#data.raw <- data.raw[,c(1,35,34,14,51,27,61,49,7,60,9,5,46,44,25,53,48,4,23,17,41,43,33,13,19,40)]
data.raw <- data.raw.0[,-1]
dim(data.raw)
data.training.tem <- data.raw

############## -----leave one out cross validation error calculation----- ###############
############################################################################################################################
##### for T0
data.training = cbind(data.training.tem[, 2:23], data.training.tem[, 1])
colnames(data.training)[23] = "es"
data.training$es

#fn.backward.feature.cv(data.training, data.training, seed = 127, model = "rf", ntree = 5000)
#fn.backward.feature.cv(data.training, data.training, seed = 127, model = "svr", ntree)
#fn.backward.feature.cv(data.training, data.training, seed = 127, model = "gboosting", ntree)
#fn.backward.feature.cv(data.training, data.training, seed = 127, model = "krr", ntree)
fn.backward.feature.cv(data.training, data.training, seed = 127, model = "linear", ntree)

