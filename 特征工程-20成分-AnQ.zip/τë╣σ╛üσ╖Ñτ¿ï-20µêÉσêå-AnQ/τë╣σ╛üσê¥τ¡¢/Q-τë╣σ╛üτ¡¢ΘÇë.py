#pearson特征筛选
import pandas as pd
import numpy as np

cor_features = pd.read_csv("Q-归一化描述符-皮尔逊相关性分析.csv")
imp_feature = pd.read_csv("Q-归一化描述符-重要性排序.csv")

best_feature = []
feature_importance = []
while cor_features.shape[1] > 0:
    a = list(np.abs(cor_features.iloc[0, :]) >= 0.95)# 特征之间相关性绝对值大于0.8的选择与目标性能更重要的那个特征
    b = []
    c = []
    for j in range(0, cor_features.shape[1]):
        if a[j]:
            b.append(j)
            c.append(imp_feature.iloc[j])
    best_idex = b[np.argmax(c)]
    best_feature.append(cor_features.columns[best_idex])
    feature_importance.append(np.max(c))
    cor_features.drop(cor_features.iloc[:, b], axis = 1, inplace=True)
    cor_features.drop(cor_features.index[b], axis = 0, inplace=True)
    imp_feature.drop(imp_feature.index[b], axis = 0, inplace=True)
print(list(zip(best_feature, feature_importance)))




