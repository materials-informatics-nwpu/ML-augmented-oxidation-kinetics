setwd("E:/硕士论文流程/RHEAs高温强度/特征筛选/1000RT-皮尔逊特征筛选-向后特获筛选")
library(randomForest)
library(xgboost)
library(neuralnet)
library(e1071)
library(corrplot)
library(gbm)
library(corrgram)
library(psych)
library(ggplot2)
library(minerva)
#source("functions.R")
source('functions.new.R')
#################数据读取#####
data.raw.0 <- read.csv("RHEAs.1000.RT.feature.csv")
data.raw.1 <- data.raw.0[,14:75]
data.raw.2 <- data.frame(data.raw.0[,76])
data.raw <- cbind(data.raw.2,data.raw.1)
dim(data.raw)
colnames(data.raw) = c('es','D1','D2','D3','D4','D5','D6','D7','D8','D9','D10',
                       'D11','D12','D13','D14','D15','D16','D17','D18','D19','D20',
                       'D21','D22','D23','D24','D25','D26','D27','D28','D29','D30',
                       'D31','D32','D33','D34','D35','D36','D37','D38','D39','D40',
                       'D41','D42','D43','D44','D45','D46','D47','D48','D49','D50',
                       'D51','D52','D53','D54','D55','D56','D57','D58','D59','D60',
                       'D61','D62')#,'D63') ##zs-es代表性质列
#删除与电阻有关的特征,计算的时候就删除了
#data.raw <- data.raw[,c(-38,-39)]
##删除特征未inf的两行数据，因为无法算该特征的Pearson
#data.raw <- data.raw[-11:-12,]
dim(data.raw)
#write.csv(data.raw, "zhaoshang.rheas.92datas.61features.csv")
#####删除为0的量######
# sum.zero = apply(data.raw, 2, function(x) sum(x)) ##zs--对数据框data.raw进行列运算，定义的函数，求和
# sum.zero = data.frame(t(sum.zero)) ##zs--行列变换
# data.raw = data.raw[, -which(sum.zero==0)]
# data.raw = data.raw[, -c(2:19)]

##均值方差标准化
# data.raw <- data.frame(scale(data.raw)) 

########## max-min归一化 ###########
# i <- 2 ##
# while(i <= dim(data.raw)[2]) {
#   data.raw[, i] <- (data.raw[, i]-min(data.raw[, i]))/(max(data.raw[, i])-min(data.raw[, i]))
#   i <-i+1
# }

###### pearson相关系数 ##########
######Pearson 相关系数--zs######
cor.pearson <- data.frame(cor(data.raw,method = 'pearson'))
#输出
write.csv(cor.pearson, "RHEA.1000HT.cor.pearson.未排序.csv")

# #Pearson相关系数图
# library(corrplot)
# cor_pearson <- as.matrix(cor.pearson) ##zs--数据框转化为矩阵
# #cor_pearson <- cor_pearson[1:15,1:15]
# # corrplot(cor_pearson, method = 'number', number.cex = 0.8, diag = FALSE, tl.cex = 0.8)
# # corrplot(cor_pearson, add = TRUE, type = 'upper', method = 'pie', diag = FALSE, tl.pos = 'n', cl.pos = 'n')
# cor.pearson.abs <- abs(cor.pearson$es)
# cor.pearson <- cor.pearson[order(-abs(cor.pearson$es)),]
# #输出
# #write.csv(cor.pearson, "cor.pearson.排序.csv")

######  MIC 最大互信息系数--用来衡量两个特征变量之间的线性或非线性关联程度  ######
######MIC 最大互信息系数--zs######
# library(minerva)
# cor.mic <- mine(data.raw)
# cor.mic <- as.data.frame(cor.mic$MIC)
# #MIC相关系数图
# # library(corrplot)
# # cor_mic <- as.matrix(cor.mic) ##zs--数据框转化为矩阵
# # corrplot(cor_mic, method = 'number', number.cex = 0.8, diag = FALSE, tl.cex = 0.8)
# # corrplot(cor_mic, add = TRUE, type = 'upper', method = 'pie', diag = FALSE, tl.pos = 'n', cl.pos = 'n')
# cor.mic <- cor.mic[order(-cor.mic$es),]
# #输出
# #write.csv(cor.mic, "cor.mic.排序.csv")

######RF-gini系数-特征重要性排序######
df <- data.raw
#删除特征未-Inf的两行数据
#df <- df[-11:-12,]
set.seed(1234)
train <- sample(nrow(df),1*nrow(df))
df.train <- df[train,]
#df.validate <- df[-train,]
table(df.train$es)
#table(df.validate$class)
###随机森林
library(randomForest)
fit.forest<-randomForest(es~.,data=df.train,na.action=na.roughfix,importance=TRUE)
fit.forest
a<-data.frame(importance(fit.forest,type = 2))
#输出
write.csv(a,file = "RHEAs.1000HT.feature.gini.csv",row.names = TRUE)

######按照随机森林重要性对Pearson>0.8的特征进行筛选
#D5,D6,D14,D16,D18,D24,D25,D28,D33,D34,D36,D39,D40,D42,D43,D48,D52,D53,D54,D59,D61,D62
data.raw <- data.raw[,c(1,6,7,15,17,19,25,26,29,34,35,37,40,41,43,44,49,53,54,55,60,62,63)]
dim(data.raw)
#输出
write.csv(data.raw,file = "RHEAs.1000HT.feature.Pearson剩余22.csv",row.names = TRUE)



# 
# #根据RF算法下的向前特征选择确定的6个特征，D33,D42,D62,D44,D26,D21
# #data.raw <- data.raw[,c(1,34,41,61,43,27,22)]
# 
# ########## Models --自助法#########
# n = dim(data.raw)[1]
# set.seed(207)
# index = sample(n, round(0.8*n), replace = F)
# data.elastic.train = data.raw[index,]
# data.elastic.test = data.raw[-index,]
# dim(data.elastic.train)
# dim(data.elastic.test)
# # write.csv(data.elastic.train, "92data.es.train.csv")
# # write.csv(data.elastic.test, "92data.es.test.csv")
# ########### SVR-boostrap #############
# #旧函数
# # svr.elastic.train = fn.boot.prop.mean.error(data.elastic.train, data.elastic.train, 
# #                                             "SVR.rbf", 206, 1, es)
# # svr.elastic.test = fn.boot.prop.mean.error(data.elastic.train, data.elastic.test, 
# #                                            "SVR.rbf", 206, 1, es)
# #cor(data.elastic.train$es,svr.elastic.train$mean)^2
# #cor(data.elastic.test$es,svr.elastic.test$mean)^2
# #####新函数
# svr.elastic.train = fn.boot.prop.mean.error(data.elastic.train,data.elastic.train, 206, 'svr', 10, ntree, mtry)
# svr.elastic.test = fn.boot.prop.mean.error(data.elastic.train,data.elastic.test, 206, 'svr', 10, ntree, mtry)
# 
# sum((data.elastic.train$es-svr.elastic.train$mean)^2)/dim(data.elastic.train)[1]
# sum((data.elastic.test$es-svr.elastic.test$mean)^2)/dim(data.elastic.test)[1]
# 
# #aa <- cbind(data.elastic.test$es,svr.elastic.test)
# ##画图
# plot(svr.elastic.train$mean ~ data.elastic.train$es, xlab = "Measured Values", ylab = "Predicted Values",
#      pch = 1, col = "darkblue", cex = 1.5, bg="darkblue", xlim = c(50, 1200), ylim = c(50, 1200), main = "svr.es")
# #arrows(data.elastic.train$es, svr.elastic.train$mean - 0.5*svr.elastic.train$sd, data.elastic.train$es, svr.elastic.train$mean + 0.5*svr.elastic.train$sd, length = 0.08, angle = 90, code = 3, col = "darkblue")
# ##加测试集的点
# points(data.elastic.test$es, svr.elastic.test$mean,pch = 1, col = "red", cex = 1.5, bg="darkblue")
# abline(0,1, col = "green", lwd = 1.0)
# data.SVR.cast = cbind(data.elastic.test$es, svr.elastic.test$mean, svr.elastic.test$sd)
# colnames(data.SVR.cast) = c("es", "mean", "sd")
# #求R^2,X1真实值，X2预测值
# R_R.svr.train <- 1-sum((data.elastic.train$es-svr.elastic.train$mean)^2)/sum((data.elastic.train$es-mean(data.elastic.train$es))^2)
# R_R.svr.test <- 1-sum((data.elastic.test$es-svr.elastic.test$mean)^2)/sum((data.elastic.test$es-mean(data.elastic.test$es))^2)
# #rmse
# rmse.svr.train <- sqrt((sum((data.elastic.train$es-svr.elastic.train$mean)^2))/dim(data.elastic.train)[1])
# rmse.svr.test <- sqrt((sum((data.elastic.test$es-svr.elastic.test$mean)^2))/dim(data.elastic.test)[1])
# 
# ######RF-boostrap######
# #旧函数
# # rf.elastic.train.2 = fn.boot.prop.mean.error(data.elastic.train, data.elastic.train, 
# #                                              "RF", 209, 1, es)
# # rf.elastic.test.2 = fn.boot.prop.mean.error(data.elastic.train, data.elastic.test, 
# #                                             "RF", 209, 1, es)
# #新函数
# rf.elastic.train.2 = fn.boot.prop.mean.error(data.elastic.train,data.elastic.train, 209, 'rf', 1, ntree=500, mtry=2)
# rf.elastic.test.2 = fn.boot.prop.mean.error(data.elastic.train,data.elastic.test, 209, 'rf', 1, ntree=500, mtry=2)
# 
# plot(data.elastic.train$es,rf.elastic.train.2$mean, xlab = "Measured Values", ylab = "Predicted Values",
#      pch = 1, col = "purple", cex = 1.5, bg="darkblue", xlim = c(50, 1200), ylim = c(50, 1200), main = "rf.2.es")
# #arrows(data.elastic.train$es, svr.elastic.train$mean - 0.5*svr.elastic.train$sd, data.elastic.train$es, svr.elastic.train$mean + 0.5*svr.elastic.train$sd, length = 0.08, angle = 90, code = 3, col = "darkblue")
# ##加测试集的点
# points(data.elastic.test$es, rf.elastic.test.2$mean,pch = 1, col = "red", cex = 1.5, bg="darkblue")
# abline(0,1, col = "green", lwd = 1.0)
# data.rf.cast = cbind(data.elastic.test$es, rf.elastic.test.2$mean, rf.elastic.test.2$sd)
# colnames(data.rf.cast) = c("es", "mean", "sd")
# #求R^2,X1真实值，X2预测值
# R_R.rf.train.2 <- 1-sum((data.elastic.train$es-rf.elastic.train.2$mean)^2)/sum((data.elastic.train$es-mean(data.elastic.train$es))^2)
# R_R.rf.test.2 <- 1-sum((data.elastic.test$es-rf.elastic.test.2$mean)^2)/sum((data.elastic.test$es-mean(data.elastic.test$es))^2)
# 
# #rmse
# rmse.rf.train <- sqrt((sum((data.elastic.train$es-rf.elastic.train.2$mean)^2))/dim(data.elastic.train)[1])
# rmse.rf.test <- sqrt((sum((data.elastic.test$es-rf.elastic.test.2$mean)^2))/dim(data.elastic.test)[1])
# #线性模型看拟合效果
# # lm = lm(rf.elastic.train.2$mean~data.elastic.train$es)
# # summary(lm)
# # 
# # lm = lm(rf.elastic.test.2$mean~data.elastic.test$es)
# # summary(lm)
# 
# # ########## GB--boostrap ####
# #旧函数
# # gb.elastic.train = fn.boot.prop.mean.error(data.elastic.train, data.elastic.train,
# #                                            "GB", 207, 10, es)
# # gb.elastic.test = fn.boot.prop.mean.error(data.elastic.train, data.elastic.test,
# #                                          "GB", 207, 10, es)
# #新函数
# gb.elastic.train = fn.boot.prop.mean.error(data.elastic.train,data.elastic.train, 207, 'gboosting', 1, ntree, mtry)
# gb.elastic.test = fn.boot.prop.mean.error(data.elastic.train,data.elastic.test, 207, 'gboosting', 1, ntree, mtry)
# 
# # cor(data.elastic.train$es,gb.elastic.train$mean)^2
# # cor(data.elastic.test$es,gb.elastic.test$mean)^2
# ##画图
# plot(gb.elastic.train$mean ~ data.elastic.train$es, xlab = "Measured Values", ylab = "Predicted Values",
#      pch = 1, col = "black", cex = 1.5, bg="darkblue", xlim = c(50, 1200), ylim = c(50, 1200), main = "gb.es")
# #arrows(data.elastic.train$es, svr.elastic.train$mean - 0.5*svr.elastic.train$sd, data.elastic.train$es, svr.elastic.train$mean + 0.5*svr.elastic.train$sd, length = 0.08, angle = 90, code = 3, col = "darkblue")
# ##加测试集的点
# points(data.elastic.test$es, gb.elastic.test$mean,pch = 1, col = "orange", cex = 1.5)#, bg="darkblue")
# abline(0,1, col = "green", lwd = 1.0)
# #data.SVR.cast = cbind(data.elastic.train$es, svr.elastic.train$mean, svr.elastic.train$sd)
# #colnames(data.SVR.cast) = c("es", "mean", "sd")
# #求R^2,X1真实值，X2预测值
# R_R.gb.train <- 1-sum((data.elastic.train$es-gb.elastic.train$mean)^2)/sum((data.elastic.train$es-mean(data.elastic.train$es))^2)
# R_R.gb.test <- 1-sum((data.elastic.test$es-gb.elastic.test$mean)^2)/sum((data.elastic.test$es-mean(data.elastic.test$es))^2)
# #rmse
# rmse.gb.train <- sqrt((sum((data.elastic.train$es-gb.elastic.train$mean)^2))/dim(data.elastic.train)[1])
# rmse.gb.test <- sqrt((sum((data.elastic.test$es-gb.elastic.test$mean)^2))/dim(data.elastic.test)[1])
# # rr2.train <- sum((gb.elastic.train$mean-mean(data.elastic.train$es))^2)/sum((data.elastic.train$es-mean(data.elastic.train$es))^2)
# # rr2.test <- sum((gb.elastic.test$mean-mean(data.elastic.test$es))^2)/sum((data.elastic.test$es-mean(data.elastic.test$es))^2)
# # 训练集
# data_result1 <- data.frame(data.elastic.train$es,  svr.elastic.train$mean,
#                            rf.elastic.train.2$mean,
#                            gb.elastic.train$mean)
# #测试集
# data_result2 <- data.frame(data.elastic.test$es, svr.elastic.test$mean,
#                            rf.elastic.test.2$mean,
#                            gb.elastic.test$mean)
# data.R_R <- data.frame(R_R.svr.train,  R_R.svr.test,
#                              R_R.rf.train.2, R_R.rf.test.2,
#                              R_R.gb.train,  R_R.gb.test)
# data.rmse <- data.frame(rmse.svr.train,rmse.svr.test,
#                         rmse.rf.train,rmse.rf.test,
#                         rmse.gb.train,rmse.gb.test)

#输出
# write.csv(data_result1, "data_resultm1.csv")
# write.csv(data_result2, "data_resultm2.csv")
# write.csv(data.R_R, "data.R_R.csv")
# write.csv(data.rmse, "data.rmse.csv")

######8：2分,iteration50次######
# df <- data.raw
# R_R.svr.train.11.mean <- c()
# R_R.svr.test.11.mean <- c()
# R_R.rf.train.11.mean <- c()
# R_R.rf.test.11.mean <- c()
# R_R.gb.train.11.mean <- c()
# R_R.gb.test.11.mean <- c()
# j <-1
# R_R.svr.train.11 <- c()
# R_R.svr.test.11 <- c()
# R_R.rf.train.11 <- c()
# R_R.rf.test.11 <- c()
# R_R.gb.train.11 <- c()
# R_R.gb.test.11 <- c()
# for(j in 1:5){
#   set.seed(j)
#   train <- sample(nrow(df),0.8*nrow(df))
#   df.train.es <- df[train,]
#   df.test.es <- df[-train,]
#   #####选取特征#####
#   #df.train.uam.am <- df.train.uam.am[,c(1,34,36,38,59)]
#   #df.test.uam.am <- df.test.uam.am[,c(1,34,36,38,59)]
#   #names(df.train.uam.am)[1] <- "class"
#   #df.train.uam.am[,"class"] <- as.factor(df.train.uam.am$class)
#   #names(df.test.uam.am)[1] <- "class"
#   #df.test.uam.am[,"class"] <- as.factor(df.test.uam.am$class)
#   ######svr######
#   svr.es.train = fn.model.svr.rbf(df.train.es, df.train.es)
#   svr.es.test = fn.model.svr.rbf(df.train.es, df.test.es)
#   ######画图#####
#   # plot(rf.es.train~ df.train.es$es, xlab = "Measured Values", ylab = "Predicted Values",
#   #      pch = 1, col = "purple", cex = 1.5, bg="darkblue", xlim = c(500, 2000), ylim = c(500, 2000), main = "rf.es")
#   # #arrows(df.train.es$es, svr.elastic.train$mean - 0.5*svr.elastic.train$sd, df.train.es$es, svr.elastic.train$mean + 0.5*svr.elastic.train$sd, length = 0.08, angle = 90, code = 3, col = "darkblue")
#   # ##加测试集的点
#   # points(df.test.es$es, rf.es.test,pch = 1, col = "red", cex = 1.5, bg="darkblue")
#   # abline(0,1, col = "green", lwd = 1.0)
#   # #data.SVR.cast = cbind(df.train.es$es, svr.elastic.train$mean, svr.elastic.train$sd)
#   # #colnames(data.SVR.cast) = c("es", "mean", "sd")
#   #####求R^2,X1真实值，X2预测值####
#   R_R.svr.train <- 1-sum((df.train.es$es-svr.es.train)^2)/sum((df.train.es$es-mean(df.train.es$es))^2)
#   R_R.svr.test <- 1-sum((df.test.es$es-svr.es.test)^2)/sum((df.test.es$es-mean(df.test.es$es))^2)
#   R_R.svr.train.11 <- c(R_R.svr.train.11, R_R.svr.train)
#   R_R.svr.test.11 <- c(R_R.svr.test.11, R_R.svr.test)
#   # ######rf######
#   rf.es.train = fn.model.rf(df.train.es, df.train.es)
#   rf.es.test = fn.model.rf(df.train.es, df.test.es)
#   R_R.rf.train <- 1-sum((df.train.es$es-rf.es.train)^2)/sum((df.train.es$es-mean(df.train.es$es))^2)
#   R_R.rf.test <- 1-sum((df.test.es$es-rf.es.test)^2)/sum((df.test.es$es-mean(df.test.es$es))^2)
#   R_R.rf.train.11 <- c(R_R.rf.train.11, R_R.rf.train)
#   R_R.rf.test.11 <- c(R_R.rf.test.11, R_R.rf.test)
#   ######gb######
#   gb.es.train = fn.model.Gboosting.6f(df.train.es, df.train.es)
#   gb.es.test = fn.model.Gboosting.6f(df.train.es, df.test.es)
#   R_R.gb.train <- 1-sum((df.train.es$es-gb.es.train)^2)/sum((df.train.es$es-mean(df.train.es$es))^2)
#   R_R.gb.test <- 1-sum((df.test.es$es-gb.es.test)^2)/sum((df.test.es$es-mean(df.test.es$es))^2)
#   R_R.gb.train.11 <- c(R_R.gb.train.11, R_R.gb.train)
#   R_R.gb.test.11 <- c(R_R.gb.test.11, R_R.gb.test)
#   ######输出#####
#   print(R_R.svr.train.11)
#   print(R_R.svr.test.11)
#   print(R_R.rf.train.11)
#   print(R_R.rf.test.11)
#   print(R_R.gb.train.11)
#   print(R_R.gb.test.11)
#   j <- j+1
# }
# #模型取平均
# R_R.svr.train.11.mean <- c(R_R.svr.train.11.mean, sum(R_R.svr.train.11)/5)
# R_R.svr.test.11.mean <- c(R_R.svr.test.11.mean, sum(R_R.svr.test.11)/5)
# R_R.rf.train.11.mean <- c(R_R.rf.train.11.mean, sum(R_R.rf.train.11)/5)
# R_R.rf.test.11.mean <- c(R_R.rf.test.11.mean, sum(R_R.rf.test.11)/5)
# R_R.gb.train.11.mean <- c(R_R.gb.train.11.mean, sum(R_R.gb.train.11)/5)
# R_R.gb.test.11.mean <- c(R_R.gb.test.11.mean, sum(R_R.gb.test.11)/5)
# 
# R_R.svr.train.11.mean
# R_R.svr.test.11.mean
# R_R.rf.train.11.mean
# R_R.rf.test.11.mean
# R_R.gb.train.11.mean
# R_R.gb.test.11.mean

########k折交叉验证######
# aa <- data.raw[,c(1,7,27,62,35,51,
#                   9,63,34,46,37,
#                   5,48,38,26,39,
#                   17,33,25,4,42,
#                   52,23,22,45,43,
#                   29,19)]
# #aa <- data.raw[,c(1,34,36,38,59)]
# #aa<- read.csv('交叉验证示例.csv')
# #查看变量性质
# str(aa)
# #批量数值转因子
# #for (i in names(aa)[c(4:9)]){aa[,i] <- as.factor(aa[,i])}
# #再次检查变量性质
# #str(aa)
# ###数据分割
# #设置随机种子，使数据分割可重复
# set.seed(1)
# #多次K折交叉验证,如10折5次交叉验证
# folds <-createMultiFolds(y=aa$es,k=10,times=5)
# ######模型预测#####
# ######svr######
# #分别建立一个放R^2和rmse的空向量
# R.R.train<-as.numeric()
# R.R.test<-as.numeric()
# rmse.train <- as.numeric()
# rmse.test <- as.numeric()
# for(i in 1:50){
#   train<- aa[ folds[[i]],] #folds[[i]]作为测试集
#   test <- aa[-folds[[i]],] #剩下的数据作为训练集
#   svr.es.train = fn.model.svr.rbf(train, train)
#   svr.es.test = fn.model.svr.rbf(train, test)
#   #auc_value<- append(auc_value,as.numeric(auc(as.numeric(test[,1]),model_pre)))#适用于分类
#   R_R.svr.train <- 1-sum((train$es-svr.es.train)^2)/sum((train$es-mean(train$es))^2)
#   R_R.svr.test <- 1-sum((test$es-svr.es.test)^2)/sum((test$es-mean(test$es))^2)
#   R.R.train <- append(R.R.train,R_R.svr.train)
#   R.R.test <- append(R.R.test,R_R.svr.test)
#   rmse.svr.train <- sqrt(sum((train$es-svr.es.train)^2)/dim(train)[1])
#   rmse.svr.test <- sqrt(sum((test$es-svr.es.test)^2)/dim(test)[1])
#   rmse.train <- append(rmse.train,rmse.svr.train)
#   rmse.test <- append(rmse.test,rmse.svr.test)
# }
# #查看auc值分及平均auc
# #summary(auc_value)
# mean(R.R.train) 
# mean(R.R.test) 
# mean(rmse.train) 
# mean(rmse.test) 
#######rf######
# R.R.train.2<-as.numeric()
# R.R.test.2<-as.numeric()
# rmse.train.2 <- as.numeric()
# rmse.test.2 <- as.numeric()
# for(i in 1:50){
#   train<- aa[ folds[[i]],] #folds[[i]]作为测试集
#   test <- aa[-folds[[i]],] #剩下的数据作为训练集
#   rf.es.train = fn.model.rf(train, train)
#   rf.es.test = fn.model.rf(train, test)
#   R_R.rf.train <- 1-sum((train$es-rf.es.train)^2)/sum((train$es-mean(train$es))^2)
#   R_R.rf.test <- 1-sum((test$es-rf.es.test)^2)/sum((test$es-mean(test$es))^2)
#   R.R.train.2 <- append(R.R.train.2,R_R.rf.train)
#   R.R.test.2 <- append(R.R.test.2,R_R.rf.test)
#   rmse.rf.train <- sqrt(sum((train$es-rf.es.train)^2)/dim(train)[1])
#   rmse.rf.test <- sqrt(sum((test$es-rf.es.test)^2)/dim(test)[1])
#   rmse.train.2 <- append(rmse.train.2,rmse.rf.train)
#   rmse.test.2 <- append(rmse.test.2,rmse.rf.test)
# }
# #查看auc值分及平均auc
# #summary(auc_value)
# mean(R.R.train.2) 
# mean(R.R.test.2) 
# mean(rmse.train.2) 
# mean(rmse.test.2) 
