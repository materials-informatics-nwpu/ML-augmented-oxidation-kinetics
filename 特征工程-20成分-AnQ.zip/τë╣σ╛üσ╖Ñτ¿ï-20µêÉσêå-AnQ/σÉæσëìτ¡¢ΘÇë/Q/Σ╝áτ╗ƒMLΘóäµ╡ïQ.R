setwd("E:/R")

library(randomForest)
library(neuralnet)
library(e1071)
library(corrplot)
library(gbm)
library(glmnet)
source("functions-s.R")


data.del.zero <- read.csv("C:/Users/Administrator/Desktop/����/2022��¼/2022.10/R/����Է���-20/��ǰɸѡ/Q/Q-��һ��������.csv")
data.del.zero <- data.del.zero[1:20,]
n = dim(data.del.zero)[1]
set.seed(1990)
index = sample(n, round(0.8*n), replace = F)
data.train = data.del.zero[index, ]
data.test = data.del.zero[-index, ]

#�}�}�}�}�}�}�}�}�}�}SVM
set.seed(10)
svr.train = fn.boot.prop.mean.error(data.train, data.train, "SVR.rbf", 12, 5, property)
svr.test = fn.boot.prop.mean.error(data.train, data.test, "SVR.rbf", 12, 5, property)

plot(data.train$es, svr.train$mean, xlim = c(1000, 10000), ylim = c(1000, 10000), xlab = "measured", ylab = "predicted", main = "SVR.rbf")
abline(0, 1, col = "blue")
points(data.test$es, svr.test$mean, col = "red")
legend('bottomright',legend=c('training','test'), pch=18, col=c('black','red'))

r2_svr.train <- 1-sum(((data.train$es)-svr.train$mean)^2)/sum((data.train$es-mean(data.train$es))^2) 
r2_svr.test <- 1-sum(((data.train$es)-svr.test$mean)^2)/sum((data.train$es-mean(data.train$es))^2) 

mae_svr.train <- sum(abs(data.train$es-svr.train$mean))/dim(data.train)

rmse_svr.train <- sqrt(sum((data.train$es-svr.train$mean)^2)/dim(data.train)[1])
cor(data.train$es, svr.train$mean)^2
# cor(data.test$es, svr.test$mean)^2
#write.csv(svr.train$mean,file = "SVM01.csv",row.names = TRUE)

#�}�}�}�}�}�}�}�}�}�}RF
set.seed(10)
rf.train = fn.boot.prop.mean.error(data.train, data.train, "RF", 12, 500, property)
rf.test = fn.boot.prop.mean.error(data.train, data.test, "RF", 12, 500, property)

plot(data.train$es, rf.train$mean, xlim = c(1000, 10000), ylim = c(1000, 10000), xlab = "measured", ylab = "predicted", main = "RF")
abline(0, 1, col = "blue")
points(data.test$es, rf.test$mean, col = "red")
legend('bottomright',legend=c('training','test'), pch=18, col=c('black','red'))

r2_rf.train <- 1-sum(((data.train$es)-rf.train$mean)^2)/sum((data.train$es-mean(data.train$es))^2) 
r2_rf.test <- 1-sum(((data.train$es)-rf.test$mean)^2)/sum((data.train$es-mean(data.train$es))^2) 

cor(data.train$es, rf.train$mean)^2
#write.csv(rf.train$mean,file = "rf01.csv",row.names = TRUE)
#write.csv(rf.test$mean,file = "rf02.csv",row.names = TRUE)


# ######GB
# set.seed(10)
# gb.train = fn.boot.prop.mean.error(data.train, data.train, "GB", 12, 100, property)
# gb.test = fn.boot.prop.mean.error(data.train, data.test, "GB", 12, 100, property)
# 
# plot(data.train$es, gb.train$mean, xlim = c(10, 20), ylim = c(10, 20), xlab = "measured", ylab = "predicted", main = "GB.rbf")
# abline(0, 1, col = "red")
# cor(data.train$es, gb.train$mean)^2
# 
# 
# ########KRR
# set.seed(10)
# krr.train = fn.boot.prop.mean.error(data.train, data.train, "KRR", 12, 1000, property)
# krr.test = fn.boot.prop.mean.error(data.train, data.test, "KRR", 12, 1000, property)
# 
# plot(data.train$es, krr.train$mean, xlim = c(10, 20), ylim = c(10, 20), xlab = "measured", ylab = "predicted", main = "KRR.rbf")
# abline(0, 1, col = "red")
# cor(data.train$es, krr.train$mean)^2
# 
# #####����
# set.seed(10)
# lasso.train = fn.boot.prop.mean.error(data.train, data.train, "lasso.fit.6f", 12, 100, property)
# lasso.test = fn.boot.prop.mean.error(data.train, data.test, "lasso.fit.6f", 12, 100, property)
# 
# plot(data.train$es, krr.train$mean, xlim = c(10, 20), ylim = c(10, 20), xlab = "measured", ylab = "predicted", main = "KRR.rbf")
# abline(0, 1, col = "red")
# cor(data.train$es, krr.train$mean)^2


#�}�}�}�}�}�}�}�}�}�}����
set.seed(101)
linear.train = fn.boot.prop.mean.error(data.train, data.train, "lm.fit.6f", 101, 500, es)
linear.test = fn.boot.prop.mean.error(data.train, data.test, "lm.fit.6f", 101, 500, es)

plot(data.train$es, linear.train$mean, xlim = c(10000, 30000), ylim = c(10000, 30000), xlab = "measured", ylab = "predicted", main = "linear")
abline(0, 1, col = "blue")
points(data.test$es, linear.test$mean, col = "red")
legend('bottomright',legend=c('training','test'), pch=18, col=c('black','red'))
cor(data.train$es, linear.train$mean)^2

