setwd("C:/Users/Administrator/Desktop/����/2022��¼/2022.10/R/����Է���/��ǰɸѡ/A")

#Ƥ��ѷ����Է���
data.raw.1 <- read.csv("A-��һ��������.csv")
cor.pearson.1 <- data.frame(cor(data.raw,method = 'pearson'))
write.csv(cor.pearson, "A-��һ��������-Ƥ��ѷ����Է���.csv")


#��Ҫ������
#######
df <- data.raw.1
set.seed(1234)
train <- sample(nrow(df),1*nrow(df))
df.train <- df[train,]
table(df.train$es)
library(randomForest)
fit.forest<-randomForest(es~.,data=df.train,na.action=na.roughfix,importance=TRUE)
fit.forest
a<-data.frame(importance(fit.forest,type = 2))

write.csv(a,file = "A-��һ��������-��Ҫ������.csv",row.names = TRUE)


#�����ݹ�����
library(randomForest)
library(gbm)
library(e1071)
library(boot)


setwd("C:/Users/Administrator/Desktop/����/2022��¼/2022.10/R/����Է���-20/��ǰɸѡ/A")
source("functions.R")
source("forward-subset.R")

data.raw<- read.csv("A-������ɸ.csv")
#data.raw <- data.raw.0[,-1]
dim(data.raw)
data.training.tem <- data.raw

data.training = cbind(data.training.tem[, 2:13], data.training.tem[, 1])
colnames(data.training)[13] = "es"
data.training$es

fn.backward.feature.cv(data.training, data.training, seed = 127, model = "rf", ntree = 5000)
#fn.backward.feature.cv(data.training, data.training, seed = 127, model = "svr", ntree)
#fn.backward.feature.cv(data.training, data.training, seed = 127, model = "gboosting", ntree)
#fn.backward.feature.cv(data.training, data.training, seed = 127, model = "krr", ntree)
#fn.backward.feature.cv(data.training, data.training, seed = 127, model = "linear", ntree)


#�ļ��ϲ�-------------rf
setwd("C:/Users/Administrator/Desktop/����/2022��¼/2022.10/R/����Է���-20/��ǰɸѡ/A")

data.1 <- read.csv('cverror.rf1.csv')
data.2 <- read.csv('cverror.rf2.csv')
data.3 <- read.csv('cverror.rf3.csv')
data.4 <- read.csv('cverror.rf4.csv')
data.5 <- read.csv('cverror.rf5.csv')
data.6 <- read.csv('cverror.rf6.csv')
data.7 <- read.csv('cverror.rf7.csv')
data.8 <- read.csv('cverror.rf8.csv')
data.9 <- read.csv('cverror.rf9.csv')
data.10 <- read.csv('cverror.rf10.csv')
data.11 <- read.csv('cverror.rf11.csv')
data.12 <- read.csv('cverror.rf12.csv')
# data.13 <- read.csv('cverror.rf13.csv')
# data.14 <- read.csv('cverror.rf14.csv')

data.all <- rbind(data.1,data.2,data.3,data.4,data.5,data.6,data.7,data.8,data.9,data.10,
                  data.11,data.12)
write.csv(data.all,'cverror.rf.all.csv')

data.min.1 <- data.1[which.min(data.1$cverror),]
data.min.2 <- data.2[which.min(data.2$cverror),]
data.min.3 <- data.3[which.min(data.3$cverror),]
data.min.4 <- data.4[which.min(data.4$cverror),]
data.min.5 <- data.5[which.min(data.5$cverror),]
data.min.6 <- data.6[which.min(data.6$cverror),]
data.min.7 <- data.7[which.min(data.7$cverror),]
data.min.8 <- data.8[which.min(data.8$cverror),]
data.min.9 <- data.9[which.min(data.9$cverror),]
data.min.10 <- data.10[which.min(data.10$cverror),]
data.min.11 <- data.11[which.min(data.11$cverror),]
data.min.12 <- data.12[which.min(data.12$cverror),]
# data.min.13 <- data.13[which.min(data.13$cverror),]
# data.min.14 <- data.14[which.min(data.14$cverror),]

data.min.all <- rbind(data.min.1,data.min.2,data.min.3,data.min.4,data.min.5,data.min.6,data.min.7,data.min.8,data.min.9,data.min.10,
                      data.min.11,data.min.12)
write.csv(data.min.all,'cverror.rf.all.min.csv')


#�ļ��ϲ�-------------svr
setwd("C:/Users/Administrator/Desktop/����/2022��¼/2022.10/R/����Է���-20/��ǰɸѡ/A")

data.1 <- read.csv('cverror.svr1.csv')
data.2 <- read.csv('cverror.svr2.csv')
data.3 <- read.csv('cverror.svr3.csv')
data.4 <- read.csv('cverror.svr4.csv')
data.5 <- read.csv('cverror.svr5.csv')
data.6 <- read.csv('cverror.svr6.csv')
data.7 <- read.csv('cverror.svr7.csv')
data.8 <- read.csv('cverror.svr8.csv')
data.9 <- read.csv('cverror.svr9.csv')
data.10 <- read.csv('cverror.svr10.csv')
data.11 <- read.csv('cverror.svr11.csv')
data.12 <- read.csv('cverror.svr12.csv')
data.13 <- read.csv('cverror.svr13.csv')
data.14 <- read.csv('cverror.svr14.csv')

data.all <- rbind(data.1,data.2,data.3,data.4,data.5,data.6,data.7,data.8,data.9,data.10,
                  data.11,data.12,data.13,data.14)
write.csv(data.all,'cverror.svr.all.csv')

data.min.1 <- data.1[which.min(data.1$cverror),]
data.min.2 <- data.2[which.min(data.2$cverror),]
data.min.3 <- data.3[which.min(data.3$cverror),]
data.min.4 <- data.4[which.min(data.4$cverror),]
data.min.5 <- data.5[which.min(data.5$cverror),]
data.min.6 <- data.6[which.min(data.6$cverror),]
data.min.7 <- data.7[which.min(data.7$cverror),]
data.min.8 <- data.8[which.min(data.8$cverror),]
data.min.9 <- data.9[which.min(data.9$cverror),]
data.min.10 <- data.10[which.min(data.10$cverror),]
data.min.11 <- data.11[which.min(data.11$cverror),]
data.min.12 <- data.12[which.min(data.12$cverror),]
data.min.13 <- data.13[which.min(data.13$cverror),]
data.min.14 <- data.14[which.min(data.14$cverror),]

data.min.all <- rbind(data.min.1,data.min.2,data.min.3,data.min.4,data.min.5,data.min.6,data.min.7,data.min.8,data.min.9,data.min.10,
                      data.min.11,data.min.12,data.min.13,data.min.14)
write.csv(data.min.all,'cverror.svr.all.min.csv')


#�ļ��ϲ�-------------krr
setwd("C:/Users/Administrator/Desktop/����/2022��¼/2022.10/R/����Է���/��ǰɸѡ/A")

data.1 <- read.csv('cverror.krr1.csv')
data.2 <- read.csv('cverror.krr2.csv')
data.3 <- read.csv('cverror.krr3.csv')
data.4 <- read.csv('cverror.krr4.csv')
data.5 <- read.csv('cverror.krr5.csv')
data.6 <- read.csv('cverror.krr6.csv')
data.7 <- read.csv('cverror.krr7.csv')
data.8 <- read.csv('cverror.krr8.csv')
data.9 <- read.csv('cverror.krr9.csv')
data.10 <- read.csv('cverror.krr10.csv')
data.11 <- read.csv('cverror.krr11.csv')
data.12 <- read.csv('cverror.krr12.csv')
data.13 <- read.csv('cverror.krr13.csv')
data.14 <- read.csv('cverror.krr14.csv')

data.all <- rbind(data.1,data.2,data.3,data.4,data.5,data.6,data.7,data.8,data.9,data.10,
                  data.11,data.12,data.13,data.14)
write.csv(data.all,'cverror.krr.all.csv')

data.min.1 <- data.1[which.min(data.1$cverror),]
data.min.2 <- data.2[which.min(data.2$cverror),]
data.min.3 <- data.3[which.min(data.3$cverror),]
data.min.4 <- data.4[which.min(data.4$cverror),]
data.min.5 <- data.5[which.min(data.5$cverror),]
data.min.6 <- data.6[which.min(data.6$cverror),]
data.min.7 <- data.7[which.min(data.7$cverror),]
data.min.8 <- data.8[which.min(data.8$cverror),]
data.min.9 <- data.9[which.min(data.9$cverror),]
data.min.10 <- data.10[which.min(data.10$cverror),]
data.min.11 <- data.11[which.min(data.11$cverror),]
data.min.12 <- data.12[which.min(data.12$cverror),]
data.min.13 <- data.13[which.min(data.13$cverror),]
data.min.14 <- data.14[which.min(data.14$cverror),]

data.min.all <- rbind(data.min.1,data.min.2,data.min.3,data.min.4,data.min.5,data.min.6,data.min.7,data.min.8,data.min.9,data.min.10,
                      data.min.11,data.min.12,data.min.13,data.min.14)
write.csv(data.min.all,'cverror.krr.all.min.csv')



#�ļ��ϲ�-------------linear
setwd("C:/Users/Administrator/Desktop/����/2022��¼/2022.10/R/����Է���/��ǰɸѡ/A")

data.1 <- read.csv('cverror.linear1.csv')
data.2 <- read.csv('cverror.linear2.csv')
data.3 <- read.csv('cverror.linear3.csv')
data.4 <- read.csv('cverror.linear4.csv')
data.5 <- read.csv('cverror.linear5.csv')
data.6 <- read.csv('cverror.linear6.csv')
data.7 <- read.csv('cverror.linear7.csv')
data.8 <- read.csv('cverror.linear8.csv')
data.9 <- read.csv('cverror.linear9.csv')
data.10 <- read.csv('cverror.linear10.csv')
data.11 <- read.csv('cverror.linear11.csv')
data.12 <- read.csv('cverror.linear12.csv')
data.13 <- read.csv('cverror.linear13.csv')
data.14 <- read.csv('cverror.linear14.csv')

data.all <- rbind(data.1,data.2,data.3,data.4,data.5,data.6,data.7,data.8,data.9,data.10,
                  data.11,data.12,data.13,data.14)
write.csv(data.all,'cverror.linear.all.csv')

data.min.1 <- data.1[which.min(data.1$cverror),]
data.min.2 <- data.2[which.min(data.2$cverror),]
data.min.3 <- data.3[which.min(data.3$cverror),]
data.min.4 <- data.4[which.min(data.4$cverror),]
data.min.5 <- data.5[which.min(data.5$cverror),]
data.min.6 <- data.6[which.min(data.6$cverror),]
data.min.7 <- data.7[which.min(data.7$cverror),]
data.min.8 <- data.8[which.min(data.8$cverror),]
data.min.9 <- data.9[which.min(data.9$cverror),]
data.min.10 <- data.10[which.min(data.10$cverror),]
data.min.11 <- data.11[which.min(data.11$cverror),]
data.min.12 <- data.12[which.min(data.12$cverror),]
data.min.13 <- data.13[which.min(data.13$cverror),]
data.min.14 <- data.14[which.min(data.14$cverror),]

data.min.all <- rbind(data.min.1,data.min.2,data.min.3,data.min.4,data.min.5,data.min.6,data.min.7,data.min.8,data.min.9,data.min.10,
                      data.min.11,data.min.12,data.min.13,data.min.14)
write.csv(data.min.all,'cverror.linear.all.min.csv')









